'use strict';
async function getDeviceId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['_did'], (data) => {
      if (!chrome.runtime.lastError && data._did && data._did.length >= 16) {
        resolve(data._did); return;
      }
      const arr = new Uint8Array(16);
      crypto.getRandomValues(arr);
      const id = Array.from(arr).map(b => b.toString(16).padStart(2,'0')).join('')
               + '_' + Date.now().toString(36);
      chrome.storage.local.set({ _did: id }, () => resolve(id));
    });
  });
}
