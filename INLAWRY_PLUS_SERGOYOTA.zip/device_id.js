/**
 * INLAWRY+SERGOYOTA — Device ID
 * Генерирует стабильный уникальный ID устройства и сохраняет в storage.
 * Загружается первым в popup.html.
 */
'use strict';

/**
 * Возвращает стабильный deviceId (создаёт один раз, хранит в storage.local).
 * @returns {Promise<string>}
 */
async function getDeviceId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['_did'], (data) => {
      if (!chrome.runtime.lastError && data._did && data._did.length >= 16) {
        resolve(data._did);
        return;
      }
      // Генерируем новый ID — crypto random + timestamp
      const arr = new Uint8Array(16);
      crypto.getRandomValues(arr);
      const id = Array.from(arr)
        .map(b => b.toString(16).padStart(2, '0'))
        .join('') + '_' + Date.now().toString(36);
      chrome.storage.local.set({ _did: id }, () => resolve(id));
    });
  });
}
