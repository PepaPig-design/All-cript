'use strict';

const _IV_SALT = 'INLAWRY_SERGOYOTA_7_SALT_XK9M';

async function hmacSHA256(keyStr, dataStr) {
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(keyStr),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign(
    'HMAC',
    keyMaterial,
    new TextEncoder().encode(dataStr)
  );
  return Array.from(new Uint8Array(sig))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

async function generateSessionToken(keyStr, docData, deviceId) {
  const today   = new Date().toISOString().slice(0, 10);
  const payload = [
    keyStr,
    (docData && docData.expiry)  || 'NONE',
    String(docData && docData.active),
    (docData && docData.owner)   || 'ANON',
    deviceId || 'NODEV',
    today,
  ].join('|');
  return hmacSHA256(_IV_SALT + keyStr, payload);
}

async function verifySessionToken(keyStr, docData, storedToken, deviceId) {
  if (!storedToken || typeof storedToken !== 'string') return false;
  if (!keyStr || !docData) return false;
  const expected = await generateSessionToken(keyStr, docData, deviceId);
  if (!expected || expected.length !== storedToken.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) {
    diff |= expected.charCodeAt(i) ^ storedToken.charCodeAt(i);
  }
  return diff === 0;
}

async function validateCachedSession(keyStr, cachedData, cachedToken, deviceId) {
  if (!keyStr || !cachedData || !cachedToken) return false;
  return verifySessionToken(keyStr, cachedData, cachedToken, deviceId);
}
