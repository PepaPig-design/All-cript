'use strict';
const _FC = [
  'AIzaSyB4IdC3pz4pSGSCH5Ce-u_EYV1CzP9SgtY',
  'inlawry-void-keys',
  'keys',
  'key',
];

function _cfg(i) { return _FC[i]; }

function _queryUrl() {
  return 'https://firestore.googleapis.com/v1/projects/' + _cfg(1) +
         '/databases/(default)/documents:runQuery?key=' + _cfg(0);
}

function _docUrl(docName) {
  return 'https://firestore.googleapis.com/v1/' + docName + '?key=' + _cfg(0);
}

async function _queryFirestore(userKey) {
  const body = {
    structuredQuery: {
      from: [{ collectionId: _cfg(2) }],
      where: { fieldFilter: { field: { fieldPath: _cfg(3) }, op: 'EQUAL', value: { stringValue: userKey } } },
      limit: 1,
    },
  };
  const res = await fetch(_queryUrl(), {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body), cache: 'no-store',
  });
  if (!res.ok) throw new Error('HTTP_' + res.status);
  const json = await res.json();
  if (!Array.isArray(json) || !json[0] || !json[0].document) return null;
  return { name: json[0].document.name, fields: _parseFields(json[0].document.fields) };
}

async function _patchDevices(docName, devicesArray) {
  const url = _docUrl(docName) + '&updateMask.fieldPaths=devices';
  const body = { fields: { devices: { arrayValue: { values: devicesArray.map(d => ({ stringValue: d })) } } } };
  const res = await fetch(url, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body), cache: 'no-store',
  });
  if (!res.ok) throw new Error('PATCH_HTTP_' + res.status);
  return true;
}

function _parseFields(fields) {
  if (!fields || typeof fields !== 'object') return {};
  const out = {};
  for (const [k, v] of Object.entries(fields)) {
    if      (v.stringValue    !== undefined) out[k] = v.stringValue;
    else if (v.booleanValue   !== undefined) out[k] = v.booleanValue;
    else if (v.integerValue   !== undefined) out[k] = parseInt(v.integerValue, 10);
    else if (v.doubleValue    !== undefined) out[k] = parseFloat(v.doubleValue);
    else if (v.timestampValue !== undefined) out[k] = v.timestampValue;
    else if (v.arrayValue     !== undefined)
      out[k] = (v.arrayValue.values || []).map(i => i.stringValue !== undefined ? i.stringValue : String(i));
    else out[k] = null;
  }
  return out;
}

async function registerDevice(docName, data, deviceId) {
  const maxDevices = (data.max_devices !== undefined && data.max_devices !== null)
    ? parseInt(data.max_devices, 10) : null;
  let devices = Array.isArray(data.devices) ? [...data.devices] : [];
  if (devices.includes(deviceId)) return { ok: true, reason: 'ALREADY_REGISTERED' };
  if (maxDevices !== null && !isNaN(maxDevices) && maxDevices > 0 && devices.length >= maxDevices)
    return { ok: false, reason: 'DEVICE LIMIT REACHED (' + devices.length + '/' + maxDevices + ')' };
  devices.push(deviceId);
  try { await _patchDevices(docName, devices); return { ok: true, reason: 'REGISTERED' }; }
  catch (e) { return { ok: false, reason: 'PATCH_ERROR: ' + e.message }; }
}

async function unregisterDevice(docName, data, deviceId) {
  let devices = Array.isArray(data.devices) ? [...data.devices] : [];
  const idx = devices.indexOf(deviceId);
  if (idx === -1) return { ok: true, reason: 'NOT_IN_LIST' };
  devices.splice(idx, 1);
  try { await _patchDevices(docName, devices); return { ok: true, reason: 'UNREGISTERED' }; }
  catch (e) { return { ok: false, reason: 'PATCH_ERROR: ' + e.message }; }
}

async function validateKey(rawKey, deviceId) {
  const userKey = (rawKey || '').trim().toUpperCase();
  if (!userKey || userKey.length < 6)
    return { valid: false, reason: 'EMPTY KEY', data: null, token: null, docName: null };

  let doc;
  try { doc = await _queryFirestore(userKey); }
  catch (e) {
    const code = e.message || '';
    if (code.includes('HTTP_'))
      return { valid: false, reason: 'SERVER ERROR ' + code, data: null, token: null, docName: null };
    return { valid: false, reason: 'CONNECTION ERROR', data: null, token: null, docName: null };
  }

  if (!doc) return { valid: false, reason: 'INVALID KEY', data: null, token: null, docName: null };

  const data = doc.fields, docName = doc.name;
  if (data.active !== true)
    return { valid: false, reason: 'KEY REVOKED', data, token: null, docName };

  if (data.expiry) {
    const today = new Date().toISOString().slice(0,10);
    const expiry = String(data.expiry).slice(0,10);
    if (today > expiry)
      return { valid: false, reason: 'KEY EXPIRED (' + expiry + ')', data, token: null, docName };
  }

  const devReg = await registerDevice(docName, data, deviceId);
  if (!devReg.ok)
    return { valid: false, reason: devReg.reason, data, token: null, docName };

  const token = await generateSessionToken(userKey, data, deviceId);
  return { valid: true, reason: 'OK', data, token, docName };
}
