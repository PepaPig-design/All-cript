'use strict';

// ── CONFIG ───────────────────────────────────────────────────────
const _FC = [
  'AIzaSyB4IdC3pz4pSGSCH5Ce-u_EYV1CzP9SgtY',       // 0: apiKey
  'inlawry-void-keys',    // 1: projectId
  'keys',    // 2: collection
  'key',     // 3: keyField
];

function _cfg(i) { return _FC[i]; }

// ── URLS ─────────────────────────────────────────────────────────
function _queryUrl() {
  return 'https://firestore.googleapis.com/v1/projects/' + _cfg(1) +
         '/databases/(default)/documents:runQuery?key=' + _cfg(0);
}

function _docUrl(docName) {
  return 'https://firestore.googleapis.com/v1/' + docName +
         '?key=' + _cfg(0);
}

// ── QUERY — найти документ по ключу ─────────────────────────────
async function _queryFirestore(userKey) {
  const body = {
    structuredQuery: {
      from: [{ collectionId: _cfg(2) }],
      where: {
        fieldFilter: {
          field: { fieldPath: _cfg(3) },
          op: 'EQUAL',
          value: { stringValue: userKey },
        },
      },
      limit: 1,
    },
  };

  const res = await fetch(_queryUrl(), {
    method : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body   : JSON.stringify(body),
    cache  : 'no-store',
  });

  if (!res.ok) throw new Error('HTTP_' + res.status);

  const json = await res.json();
  if (!Array.isArray(json) || !json[0] || !json[0].document) return null;

  return {
    name  : json[0].document.name,
    fields: _parseFields(json[0].document.fields),
  };
}

// ── PATCH — обновить поле devices в документе ───────────────────
async function _patchDevices(docName, devicesArray) {
  // Firestore REST PATCH с field mask
  const url = _docUrl(docName) + '&updateMask.fieldPaths=devices';

  const body = {
    fields: {
      devices: {
        arrayValue: {
          values: devicesArray.map(d => ({ stringValue: d })),
        },
      },
    },
  };

  const res = await fetch(url, {
    method : 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body   : JSON.stringify(body),
    cache  : 'no-store',
  });

  if (!res.ok) throw new Error('PATCH_HTTP_' + res.status);
  return true;
}

// ── PARSE FIELDS ─────────────────────────────────────────────────
function _parseFields(fields) {
  if (!fields || typeof fields !== 'object') return {};
  const out = {};
  for (const [k, v] of Object.entries(fields)) {
    if (v.stringValue    !== undefined) { out[k] = v.stringValue; }
    else if (v.booleanValue  !== undefined) { out[k] = v.booleanValue; }
    else if (v.integerValue  !== undefined) { out[k] = parseInt(v.integerValue, 10); }
    else if (v.doubleValue   !== undefined) { out[k] = parseFloat(v.doubleValue); }
    else if (v.timestampValue !== undefined){ out[k] = v.timestampValue; }
    else if (v.arrayValue    !== undefined) {
      // Парсим массив (devices)
      out[k] = (v.arrayValue.values || []).map(item => {
        if (item.stringValue !== undefined) return item.stringValue;
        return String(item);
      });
    }
    else { out[k] = null; }
  }
  return out;
}

// ── REGISTER DEVICE ──────────────────────────────────────────────
/**
 * Регистрирует deviceId в массиве devices документа ключа.
 * Проверяет лимит max_devices.
 *
 * @param {string} docName   — полный путь документа из Firestore
 * @param {object} data      — уже спарсенные поля документа
 * @param {string} deviceId  — ID этого устройства
 * @returns {{ ok: boolean, reason: string }}
 */
async function registerDevice(docName, data, deviceId) {
  const maxDevices = (data.max_devices !== undefined && data.max_devices !== null)
    ? parseInt(data.max_devices, 10)
    : null; // null = без лимита

  let devices = Array.isArray(data.devices) ? [...data.devices] : [];

  // Устройство уже зарегистрировано — ок
  if (devices.includes(deviceId)) {
    return { ok: true, reason: 'ALREADY_REGISTERED' };
  }

  // Проверяем лимит
  if (maxDevices !== null && !isNaN(maxDevices) && maxDevices > 0) {
    if (devices.length >= maxDevices) {
      return {
        ok: false,
        reason: 'DEVICE_LIMIT_REACHED (' + devices.length + '/' + maxDevices + ')',
      };
    }
  }

  // Добавляем устройство
  devices.push(deviceId);

  try {
    await _patchDevices(docName, devices);
    return { ok: true, reason: 'REGISTERED' };
  } catch (e) {
    return { ok: false, reason: 'PATCH_ERROR: ' + e.message };
  }
}

// ── UNREGISTER DEVICE ────────────────────────────────────────────
/**
 * Удаляет deviceId из массива devices (вызывается при деактивации).
 */
async function unregisterDevice(docName, data, deviceId) {
  let devices = Array.isArray(data.devices) ? [...data.devices] : [];
  const idx   = devices.indexOf(deviceId);
  if (idx === -1) return { ok: true, reason: 'NOT_IN_LIST' };

  devices.splice(idx, 1);
  try {
    await _patchDevices(docName, devices);
    return { ok: true, reason: 'UNREGISTERED' };
  } catch (e) {
    return { ok: false, reason: 'PATCH_ERROR: ' + e.message };
  }
}

// ── VALIDATE KEY (главная функция) ───────────────────────────────
/**
 * @param {string} rawKey    — ключ введённый пользователем
 * @param {string} deviceId  — ID этого устройства
 */
async function validateKey(rawKey, deviceId) {
  const userKey = (rawKey || '').trim().toUpperCase();
  if (!userKey || userKey.length < 6) {
    return { valid: false, reason: 'EMPTY KEY', data: null, token: null, docName: null };
  }

  let doc;
  try {
    doc = await _queryFirestore(userKey);
  } catch (e) {
    const code = e.message || '';
    if (code.includes('HTTP_')) {
      return { valid: false, reason: 'SERVER ERROR ' + code, data: null, token: null, docName: null };
    }
    return { valid: false, reason: 'CONNECTION ERROR', data: null, token: null, docName: null };
  }

  if (!doc) {
    return { valid: false, reason: 'INVALID KEY', data: null, token: null, docName: null };
  }

  const data    = doc.fields;
  const docName = doc.name;

  // Проверяем active
  if (data.active !== true) {
    return { valid: false, reason: 'KEY REVOKED', data, token: null, docName };
  }

  // Проверяем expiry
  if (data.expiry) {
    const today  = new Date().toISOString().slice(0, 10);
    const expiry = String(data.expiry).slice(0, 10);
    if (today > expiry) {
      return { valid: false, reason: 'KEY EXPIRED (' + expiry + ')', data, token: null, docName };
    }
  }

  // Регистрируем устройство (проверяет max_devices)
  const devReg = await registerDevice(docName, data, deviceId);
  if (!devReg.ok) {
    return { valid: false, reason: devReg.reason, data, token: null, docName };
  }

  // Генерируем токен (deviceId включён в подпись)
  const token = await generateSessionToken(userKey, data, deviceId);
  return { valid: true, reason: 'OK', data, token, docName };
}
