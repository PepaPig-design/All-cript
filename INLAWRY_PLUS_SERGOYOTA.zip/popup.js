'use strict';

/* ── UTILS ── */
const $ = id => document.getElementById(id);
function _esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function _hexToRgb(hex){
  return {
    r: parseInt(hex.slice(1,3),16),
    g: parseInt(hex.slice(3,5),16),
    b: parseInt(hex.slice(5,7),16),
  };
}
function _rgbToHex(r,g,b){
  return '#'+[r,g,b].map(v=>Math.max(0,Math.min(255,v)).toString(16).padStart(2,'0')).join('');
}

/* ── PRESETS ── */
const PRESETS = {
  red:   { accent:'#ff2d2d', hud:'#080000' },
  blue:  { accent:'#1a6fff', hud:'#000508' },
  green: { accent:'#1aff6f', hud:'#000802' },
  purple:{ accent:'#9b1aff', hud:'#040008' },
  gold:  { accent:'#ffaa1a', hud:'#080500' },
  cyan:  { accent:'#1affee', hud:'#000708' },
  white: { accent:'#e8e8e8', hud:'#080808' },
  pink:  { accent:'#ff1a8c', hud:'#080003' },
};

/* ── STATE ── */
let _licensed      = false;
let _deviceId      = null;
let _licenseData   = null;
let _licenseKey    = null;
let _popupRevTimer = null;
let _statsTimer    = null;
let _accentHex     = '#ff2d2d';
let _hudHex        = '#080000';
let _opacity       = 80;
let _saveTimer     = null;

/* ── APPLY ACCENT TO POPUP UI ── */
function _applyAccentToUI(hex) {
  const rgb = _hexToRgb(hex);
  document.documentElement.style.setProperty('--accent', `${rgb.r},${rgb.g},${rgb.b}`);
}

/* ── NAV ── */
const mainNav = $('main-nav');

function _showPage(id) {
  // Скрываем все страницы
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('active');
    p.style.display = 'none';
  });
  // Снимаем активность с nav
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));

  // Если залогинен — lock всегда скрыт
  if (_licensed && id === 'page-lock') id = 'page-home';

  const page = $(id);
  if (page) {
    page.style.display = id === 'page-lock' ? 'flex' : 'block';
    page.classList.add('active');
  }

  const btn = document.querySelector(`.nav-item[data-page="${id}"]`);
  if (btn) btn.classList.add('active');

  if (id === 'page-profile') _renderDevices();
}

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    if (!_licensed) return;
    _showPage(btn.dataset.page);
  });
});

/* ── LOCK SCREEN ── */
const lockInput   = $('lock-input');
const lockBtn     = $('lock-btn');
const lockSpinner = $('lock-spinner');
const lockStatus  = $('lock-status');

function _setStatus(msg, type) {
  if (!lockStatus) return;
  lockStatus.textContent = msg || '';
  lockStatus.className = 'lock-status' + (type ? ' ' + type : '');
}

if (lockInput) {
  lockInput.addEventListener('input', () => {
    lockInput.value = lockInput.value.toUpperCase().replace(/[^A-Z0-9\-]/g,'');
  });
  lockInput.addEventListener('keydown', e => { if (e.key === 'Enter') _activate(); });
}
if (lockBtn) lockBtn.addEventListener('click', _activate);

async function _activate() {
  if (!lockInput) return;
  const raw = lockInput.value.trim().toUpperCase();
  if (!raw) { _setStatus('Enter a key', 'checking'); return; }

  lockBtn.disabled = true;
  lockSpinner.classList.add('show');
  _setStatus('Checking…', 'checking');

  _deviceId = await getDeviceId();

  let result;
  try { result = await validateKey(raw, _deviceId); }
  catch (e) {
    _setStatus('Connection error', 'error');
    lockBtn.disabled = false;
    lockSpinner.classList.remove('show');
    return;
  }
  lockSpinner.classList.remove('show');

  if (result && result.valid) {
    chrome.storage.local.set({
      licenseKey    : raw,
      licenseData   : result.data,
      licenseToken  : result.token,
      licenseDocName: result.docName,
    }, () => {
      if (chrome.runtime.lastError) {
        _setStatus('Storage error', 'error');
        lockBtn.disabled = false;
        return;
      }
      _setStatus('Activated!', 'success');
      _licenseKey  = raw;
      _licenseData = result.data;
      setTimeout(() => { _enterMainUI(); _startRevTimer(); }, 500);
    });
  } else {
    _setStatus((result && result.reason) || 'Invalid key', 'error');
    lockBtn.disabled = false;
    if (lockInput) {
      lockInput.style.animation = 'none';
      void lockInput.offsetWidth;
      lockInput.style.animation = 'shake 0.4s ease';
    }
  }
}

/* ── ENTER MAIN UI ── */
function _enterMainUI() {
  _licensed = true;

  // Полностью прячем lock страницу
  const lockPage = $('page-lock');
  if (lockPage) {
    lockPage.classList.remove('active');
    lockPage.style.display = 'none';
  }

  // Сбрасываем поля ввода
  if (lockInput)   lockInput.value = '';
  if (lockStatus)  lockStatus.textContent = '';
  if (lockBtn)     lockBtn.disabled = false;
  if (lockSpinner) lockSpinner.classList.remove('show');

  // Показываем навигацию
  if (mainNav) mainNav.style.display = 'flex';

  _updateHeader();
  _showPage('page-home');
  _loadSettings();
  _startStats();
}

/* ── HEADER UPDATE ── */
function _updateHeader() {
  const owner   = (_licenseData && _licenseData.owner) || 'USER';
  const initials= owner.slice(0,2).toUpperCase();

  const hdrAv   = $('hdr-av');
  const hdrName = $('hdr-name');
  const hdrId   = $('hdr-id');
  const hdrBadge= $('hdr-badge');

  if (hdrAv)    hdrAv.textContent = initials;
  if (hdrName)  hdrName.innerHTML = _esc(owner) +
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
  if (hdrId)    hdrId.textContent = 'ID: ' + (_deviceId || '—').slice(0,18) + '…';
  if (hdrBadge) hdrBadge.classList.add('show');

  // Profile
  const profAv    = $('prof-av');
  const profName  = $('prof-name');
  const profId    = $('prof-id');
  const profKey   = $('prof-key');
  const profOwner = $('prof-owner');
  const profExpiry= $('prof-expiry');
  const profDev   = $('prof-dev-count');

  if (profAv)     profAv.textContent    = initials;
  if (profName)   profName.textContent  = owner;
  if (profId)     profId.textContent    = 'ID: ' + (_deviceId || '—').slice(0,20) + '…';
  if (profKey)    profKey.textContent   = _licenseKey  || '—';
  if (profOwner)  profOwner.textContent = (_licenseData && _licenseData.owner)  || '—';
  if (profExpiry) profExpiry.textContent= (_licenseData && _licenseData.expiry) || '∞';

  const maxDev = (_licenseData && _licenseData.max_devices !== undefined)
    ? _licenseData.max_devices : null;
  const devArr = Array.isArray(_licenseData && _licenseData.devices)
    ? _licenseData.devices : [];
  if (profDev) profDev.textContent = devArr.length + ' / ' + (maxDev || '∞');
}

/* ── DEVICES ── */
function _renderDevices() {
  const list = $('devices-list');
  if (!list) return;
  const devArr = Array.isArray(_licenseData && _licenseData.devices)
    ? _licenseData.devices : [];
  if (devArr.length === 0) {
    list.innerHTML = '<div class="row"><div class="row-body"><div class="row-sub">No devices registered</div></div></div>';
    return;
  }
  list.innerHTML = devArr.map(d => {
    const isThis = d === _deviceId;
    const short  = d.slice(0,8) + '…' + d.slice(-6);
    return `<div class="dev-item">
      <div class="dev-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <rect x="5" y="2" width="14" height="20" rx="2"/>
          <line x1="12" y1="18" x2="12.01" y2="18"/>
        </svg>
      </div>
      <div class="dev-id">${_esc(short)}</div>
      <span class="dev-badge ${isThis ? 'this' : 'other'}">${isThis ? 'THIS' : 'OTHER'}</span>
    </div>`;
  }).join('');
}

/* ── LOGOUT ── */
const logoutBtn = $('logout-btn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', async () => {
    _stopRevTimer();
    if (_statsTimer) { clearInterval(_statsTimer); _statsTimer = null; }

    const stored = await new Promise(res =>
      chrome.storage.local.get(['licenseDocName','licenseData','_did'],
        d => res(chrome.runtime.lastError ? {} : d))
    );
    if (stored.licenseDocName && stored.licenseData && stored._did) {
      try { await unregisterDevice(stored.licenseDocName, stored.licenseData, stored._did); }
      catch (_) {}
    }

    chrome.storage.local.remove(
      ['licenseKey','licenseData','licenseToken','licenseDocName'],
      () => {
        _licensed    = false;
        _licenseData = null;
        _licenseKey  = null;

        // Скрываем nav
        if (mainNav) mainNav.style.display = 'none';

        // Сбрасываем header
        const hdrBadge = $('hdr-badge');
        if (hdrBadge) hdrBadge.classList.remove('show');
        const hdrAv = $('hdr-av');
        if (hdrAv) hdrAv.textContent = 'IN';
        const hdrName = $('hdr-name');
        if (hdrName) hdrName.innerHTML = 'INLAWRY<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        const hdrId = $('hdr-id');
        if (hdrId) hdrId.textContent = 'Enter your key to activate';

        // Сбрасываем поля
        _setStatus('');
        if (lockInput)   lockInput.value = '';
        if (lockBtn)     lockBtn.disabled = false;
        if (lockSpinner) lockSpinner.classList.remove('show');

        // Скрываем все страницы кроме lock
        ['page-home','page-settings','page-tools','page-colors','page-profile'].forEach(pid => {
          const p = $(pid);
          if (p) { p.classList.remove('active'); p.style.display = 'none'; }
        });

        // Показываем lock
        const lockPage = $('page-lock');
        if (lockPage) {
          lockPage.style.display = 'flex';
          lockPage.classList.add('active');
        }
      }
    );
  });
}

/* ── REVERIFY ── */
function _startRevTimer() {
  _stopRevTimer();
  _popupRevTimer = setInterval(async () => {
    const stored = await new Promise(res =>
      chrome.storage.local.get(
        ['licenseKey','licenseData','licenseToken','_did'],
        d => res(chrome.runtime.lastError ? {} : d)
      )
    );
    const { licenseKey:key, licenseData:data, licenseToken:token, _did:devId } = stored;

    if (!key || !data || !token || !devId) {
      _stopRevTimer();
      _goToLock('Session expired — enter new key');
      return;
    }
    let ok = false;
    try { ok = await validateCachedSession(key, data, token, devId); } catch (_) {}
    if (!ok) {
      _stopRevTimer();
      chrome.storage.local.remove(['licenseKey','licenseData','licenseToken','licenseDocName']);
      if (lockInput && key) lockInput.value = key;
      _goToLock('Key expired — enter new key');
    }
  }, 60 * 1000);
}

function _stopRevTimer() {
  if (_popupRevTimer) { clearInterval(_popupRevTimer); _popupRevTimer = null; }
}

function _goToLock(msg) {
  _licensed = false;
  if (mainNav) mainNav.style.display = 'none';
  if (_statsTimer) { clearInterval(_statsTimer); _statsTimer = null; }

  ['page-home','page-settings','page-tools','page-colors','page-profile'].forEach(pid => {
    const p = $(pid);
    if (p) { p.classList.remove('active'); p.style.display = 'none'; }
  });

  const lockPage = $('page-lock');
  if (lockPage) {
    lockPage.style.display = 'flex';
    lockPage.classList.add('active');
  }
  _setStatus(msg || '', 'error');
}

/* ── STARTUP ── */
(async function _init() {
  // Скрываем nav по умолчанию
  if (mainNav) mainNav.style.display = 'none';

  // Скрываем все страницы кроме lock
  ['page-home','page-settings','page-tools','page-colors','page-profile'].forEach(pid => {
    const p = $(pid);
    if (p) { p.style.display = 'none'; p.classList.remove('active'); }
  });

  _deviceId = await getDeviceId();

  const stored = await new Promise(res =>
    chrome.storage.local.get(
      ['licenseKey','licenseData','licenseToken'],
      d => res(chrome.runtime.lastError ? {} : d)
    )
  );
  const { licenseKey:key, licenseData:data, licenseToken:token } = stored;
  if (!key || !data || !token) return;

  let ok = false;
  try { ok = await validateCachedSession(key, data, token, _deviceId); } catch (_) {}

  if (ok) {
    _licenseKey  = key;
    _licenseData = data;
    _enterMainUI();
    _startRevTimer();
  } else {
    chrome.storage.local.remove(['licenseKey','licenseData','licenseToken','licenseDocName']);
    _setStatus('Session expired — re-enter key', 'error');
    if (lockInput && key) lockInput.value = key;
  }

  // Загружаем сохранённые цвета
  _loadSavedColors();
})();

/* ── LOAD SAVED COLORS ── */
function _loadSavedColors() {
  chrome.storage.local.get(['theme'], data => {
    if (chrome.runtime.lastError || !data.theme) return;
    const t = data.theme;
    if (t.accentR !== undefined) {
      _accentHex = _rgbToHex(t.accentR, t.accentG, t.accentB);
    }
    if (t.hudR !== undefined) {
      _hudHex = _rgbToHex(t.hudR, t.hudG, t.hudB);
    }
    if (t.opacity !== undefined) _opacity = t.opacity;
    _applyColorUI();
    _applyAccentToUI(_accentHex);
  });
}

/* ── SETTINGS ── */
function _syncToggle(key, ids) {
  ids.forEach(id => {
    const el = $(id); if (!el) return;
    el.addEventListener('change', () => {
      const val = el.checked;
      chrome.storage.local.set({ [key]: val });
      ids.forEach(oid => {
        const oel = $(oid);
        if (oel && oel !== el) oel.checked = val;
      });
    });
  });
}

_syncToggle('engine4K',   ['tog-engine','tog-engine2']);
_syncToggle('autoScroll', ['tog-scroll','tog-scroll2']);
_syncToggle('ghostMode',  ['tog-ghost','tog-ghost2']);
_syncToggle('autoPromo',  ['tog-promo']);

const sliderScale = $('slider-scale');
const scaleVal    = $('scale-val');
if (sliderScale) {
  sliderScale.addEventListener('input', () => {
    const v = parseFloat(sliderScale.value);
    if (scaleVal) scaleVal.textContent = v.toFixed(2) + 'x';
    chrome.storage.local.set({ uiScale: v });
  });
}

function _loadSettings() {
  chrome.storage.local.get(
    ['autoScroll','engine4K','ghostMode','autoPromo','uiScale','theme'],
    data => {
      if (chrome.runtime.lastError) return;

      ['tog-engine','tog-engine2'].forEach(id => {
        const el = $(id); if (el) el.checked = data.engine4K !== undefined ? data.engine4K : true;
      });
      ['tog-scroll','tog-scroll2'].forEach(id => {
        const el = $(id); if (el) el.checked = data.autoScroll !== undefined ? data.autoScroll : true;
      });
      ['tog-ghost','tog-ghost2'].forEach(id => {
        const el = $(id); if (el) el.checked = data.ghostMode !== undefined ? data.ghostMode : false;
      });
      const promo = $('tog-promo');
      if (promo) promo.checked = data.autoPromo !== undefined ? data.autoPromo : true;

      const s = data.uiScale !== undefined ? data.uiScale : 1.0;
      if (sliderScale) sliderScale.value = s;
      if (scaleVal) scaleVal.textContent = parseFloat(s).toFixed(2) + 'x';

      if (data.theme) {
        const t = data.theme;
        if (t.accentR !== undefined) _accentHex = _rgbToHex(t.accentR, t.accentG, t.accentB);
        if (t.hudR    !== undefined) _hudHex    = _rgbToHex(t.hudR, t.hudG, t.hudB);
        if (t.opacity !== undefined) _opacity   = t.opacity;
        _applyColorUI();
        _applyAccentToUI(_accentHex);
      }
    }
  );
}

/* ── COLORS ── */
function _applyColorUI() {
  // Accent picker
  const pickA = $('pick-accent'), hexA = $('hex-accent'), prevA = $('prev-accent');
  if (pickA) pickA.value = _accentHex;
  if (hexA)  hexA.value  = _accentHex.toUpperCase();
  if (prevA) prevA.style.background = _accentHex;

  // Hud picker
  const pickH = $('pick-hud'), hexH = $('hex-hud'), prevH = $('prev-hud');
  if (pickH) pickH.value = _hudHex;
  if (hexH)  hexH.value  = _hudHex.toUpperCase();
  if (prevH) prevH.style.background = _hudHex;

  // Opacity
  const slOp = $('slider-op'), opVal = $('op-val');
  if (slOp)  slOp.value = _opacity;
  if (opVal) opVal.textContent = _opacity + '%';
}

function _saveTheme() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    const aRgb = _hexToRgb(_accentHex);
    const hRgb = _hexToRgb(_hudHex);
    chrome.storage.local.set({
      theme: {
        accentR: aRgb.r, accentG: aRgb.g, accentB: aRgb.b,
        hudR:    hRgb.r, hudG:    hRgb.g, hudB:    hRgb.b,
        opacity: _opacity,
      }
    });
    // Применяем акцент к UI
    _applyAccentToUI(_accentHex);
  }, 80);
}

function _setupPicker(pickId, hexId, prevId, key) {
  const pick = $(pickId), hex = $(hexId), prev = $(prevId);
  if (pick) {
    pick.addEventListener('input', () => {
      const val = pick.value;
      if (key === 'accent') _accentHex = val; else _hudHex = val;
      if (hex)  hex.value = val.toUpperCase();
      if (prev) prev.style.background = val;
      _saveTheme();
    });
  }
  if (hex) {
    hex.addEventListener('input', () => {
      if (!/^#[0-9a-fA-F]{6}$/.test(hex.value)) return;
      const val = hex.value;
      if (key === 'accent') _accentHex = val; else _hudHex = val;
      if (pick) pick.value = val;
      if (prev) prev.style.background = val;
      _saveTheme();
    });
    hex.addEventListener('blur', () => {
      if (!/^#[0-9a-fA-F]{6}$/.test(hex.value))
        hex.value = (key === 'accent' ? _accentHex : _hudHex).toUpperCase();
    });
  }
}

_setupPicker('pick-accent','hex-accent','prev-accent','accent');
_setupPicker('pick-hud',   'hex-hud',   'prev-hud',   'hud');

const slOp  = $('slider-op');
const opVal = $('op-val');
if (slOp) {
  slOp.addEventListener('input', () => {
    _opacity = parseInt(slOp.value);
    if (opVal) opVal.textContent = _opacity + '%';
    _saveTheme();
  });
}

// Presets
document.querySelectorAll('.swatch-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const p = PRESETS[btn.dataset.preset]; if (!p) return;
    _accentHex = p.accent;
    _hudHex    = p.hud;
    _applyColorUI();
    _saveTheme();
    document.querySelectorAll('.swatch-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});

/* ── HEADER BADGE COPY ── */
const hdrBadge = $('hdr-badge');
if (hdrBadge) {
  hdrBadge.addEventListener('click', () => {
    if (_licenseKey) {
      try { navigator.clipboard.writeText(_licenseKey); } catch (_) {}
      hdrBadge.textContent = 'COPIED!';
      setTimeout(() => { hdrBadge.textContent = 'KEY'; }, 1500);
    }
  });
}

/* ── STATS ── */
function _startStats() {
  if (_statsTimer) clearInterval(_statsTimer);
  _loadStats();
  _statsTimer = setInterval(_loadStats, 3000);
}

function _loadStats() {
  chrome.storage.local.get(['_statVideos','_statScrolls','_statSessionStart'], data => {
    if (chrome.runtime.lastError) return;
    const vidEl  = $('stat-videos');
    const scrEl  = $('stat-scrolls');
    const sessEl = $('stat-session');
    if (vidEl)  vidEl.textContent  = data._statVideos  || 0;
    if (scrEl)  scrEl.textContent  = data._statScrolls || 0;
    if (sessEl && data._statSessionStart) {
      const elapsed = Math.floor((Date.now() - data._statSessionStart) / 1000);
      const m = Math.floor(elapsed / 60);
      const s = elapsed % 60;
      sessEl.textContent = m + ':' + (s < 10 ? '0' : '') + s;
    }
  });
}
