'use strict';

/* ── COLOR UTILS ────────────────────────────────────────────── */
function _hexToRgbTriple(hex) {
  return [parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)].join(',');
}
function _rgbToHex(r,g,b) {
  return '#'+[r,g,b].map(v=>Math.max(0,Math.min(255,v)).toString(16).padStart(2,'0')).join('');
}
function _hexToRgb(hex) {
  return {r:parseInt(hex.slice(1,3),16),g:parseInt(hex.slice(3,5),16),b:parseInt(hex.slice(5,7),16)};
}
function _applyAccent(hex){ document.documentElement.style.setProperty('--accent',_hexToRgbTriple(hex)); }
function _applyBgVar(hex) { document.documentElement.style.setProperty('--bg-dark',hex); }

/* ── THEME ──────────────────────────────────────────────────── */
const PRESETS = {
  red:   {accent:'#ff1a1a',bg:'#0a0000',hud:'#080000',text:'#cccccc'},
  blue:  {accent:'#1a6fff',bg:'#00050a',hud:'#000508',text:'#cccccc'},
  green: {accent:'#1aff6f',bg:'#000a03',hud:'#000802',text:'#cccccc'},
  purple:{accent:'#9b1aff',bg:'#05000a',hud:'#040008',text:'#cccccc'},
  gold:  {accent:'#ffaa1a',bg:'#0a0700',hud:'#080500',text:'#cccccc'},
  cyan:  {accent:'#1affee',bg:'#00090a',hud:'#000708',text:'#cccccc'},
  white: {accent:'#e8e8e8',bg:'#0a0a0a',hud:'#080808',text:'#bbbbbb'},
  pink:  {accent:'#ff1a8c',bg:'#0a0005',hud:'#080003',text:'#cccccc'},
};
const DEFAULT_THEME = {
  accentR:255,accentG:26, accentB:26,
  bgR:10,     bgG:0,      bgB:0,
  hudR:8,     hudG:0,     hudB:0,
  textR:204,  textG:204,  textB:204,
};
function _themeToHex(t) {
  return {
    accent:_rgbToHex(t.accentR||255,t.accentG||26, t.accentB||26),
    bg:    _rgbToHex(t.bgR||10,     t.bgG||0,      t.bgB||0),
    hud:   _rgbToHex(t.hudR||8,     t.hudG||0,     t.hudB||0),
    text:  _rgbToHex(t.textR||204,  t.textG||204,  t.textB||204),
  };
}
function _hexToTheme(m) {
  const a=_hexToRgb(m.accent),b=_hexToRgb(m.bg),h=_hexToRgb(m.hud),t=_hexToRgb(m.text);
  return {accentR:a.r,accentG:a.g,accentB:a.b,bgR:b.r,bgG:b.g,bgB:b.b,hudR:h.r,hudG:h.g,hudB:h.b,textR:t.r,textG:t.g,textB:t.b};
}

/* ── DOM ────────────────────────────────────────────────────── */
const $=id=>document.getElementById(id);
const keyScreen=$('key-screen'),mainUI=$('main-ui'),videoSection=$('video-section');
const keyInput=$('key-input'),keyActivateBtn=$('key-activate-btn');
const keySpinner=$('key-spinner'),keyStatus=$('key-status');
const keyInfo=$('key-info'),keyLogoutBtn=$('key-logout-btn'),footerStatus=$('footer-status');

/* ── SCREENS ────────────────────────────────────────────────── */
function _showKeyScreen(msg,type) {
  if (keyScreen)    keyScreen.style.display='flex';
  if (mainUI)       mainUI.classList.remove('show');
  if (videoSection) videoSection.style.display='none';
  if (footerStatus) { footerStatus.textContent='● LOCKED'; footerStatus.style.color='#ff3333'; }
  if (msg) _setKeyStatus(msg,type||'error');
}

function _showMainUI(keyData) {
  if (keyScreen)    keyScreen.style.display='none';
  if (mainUI)       mainUI.classList.add('show');
  if (videoSection) videoSection.style.display='flex';
  if (footerStatus) { footerStatus.textContent='● ACTIVE'; footerStatus.style.color='#44ff44'; }

  if (keyData && keyInfo) {
    // Показываем max_devices если задан
    const maxDev  = keyData.max_devices !== undefined ? keyData.max_devices : null;
    const devices = Array.isArray(keyData.devices) ? keyData.devices : [];
    const devStr  = maxDev !== null
      ? `${devices.length} / ${maxDev}`
      : `${devices.length} / ∞`;

    keyInfo.innerHTML =
      `<span>KEY:</span> ${_esc(keyData.key||'—')}<br>` +
      `<span>OWNER:</span> ${_esc(keyData.owner||'—')}<br>` +
      `<span>EXPIRES:</span> ${_esc(String(keyData.expiry||'\u221E'))}<br>` +
      `<span class="dev-limit">DEVICES:</span> ${_esc(devStr)}`;
    keyInfo.classList.add('show');
  }
  if (keyLogoutBtn) keyLogoutBtn.style.display='block';
}

function _esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function _setKeyStatus(msg,type) {
  if (!keyStatus) return;
  keyStatus.textContent=msg||'';
  keyStatus.className='key-status'+(type?' '+type:'');
}

/* ── ACTIVATION ─────────────────────────────────────────────── */
if (keyInput) {
  keyInput.addEventListener('input',()=>{
    keyInput.value=keyInput.value.toUpperCase().replace(/[^A-Z0-9\-]/g,'');
  });
  keyInput.addEventListener('keydown',e=>{ if(e.key==='Enter') _activateKey(); });
}
if (keyActivateBtn) keyActivateBtn.addEventListener('click',_activateKey);

async function _activateKey() {
  if (!keyInput) return;
  const raw=keyInput.value.trim().toUpperCase();
  if (!raw) { _setKeyStatus('ENTER A KEY','checking'); return; }

  if (keyActivateBtn) keyActivateBtn.disabled=true;
  if (keySpinner)     keySpinner.classList.add('show');
  _setKeyStatus('CHECKING\u2026','checking');

  // Получаем deviceId
  const deviceId = await getDeviceId();

  let result;
  try { result=await validateKey(raw, deviceId); }
  catch(e) {
    _setKeyStatus('CONNECTION ERROR','error');
    if (keySpinner)     keySpinner.classList.remove('show');
    if (keyActivateBtn) keyActivateBtn.disabled=false;
    return;
  }
  if (keySpinner) keySpinner.classList.remove('show');

  if (result && result.valid) {
    chrome.storage.local.set(
      {
        licenseKey    : raw,
        licenseData   : result.data,
        licenseToken  : result.token,
        licenseDocName: result.docName,
      },
      ()=>{
        if (chrome.runtime.lastError) {
          _setKeyStatus('STORAGE ERROR','error');
          if (keyActivateBtn) keyActivateBtn.disabled=false;
          return;
        }
        _setKeyStatus('KEY ACTIVATED','success');
        _startReverifyTimer();
        setTimeout(()=>{ _showMainUI(result.data); _loadMainSettings(); },700);
      }
    );
  } else {
    _setKeyStatus((result&&result.reason)||'UNKNOWN ERROR','error');
    if (keyActivateBtn) keyActivateBtn.disabled=false;
    if (keyInput) {
      keyInput.style.animation='none'; void keyInput.offsetWidth;
      keyInput.style.animation='shake 0.4s ease';
    }
  }
}

/* ── DEACTIVATION ───────────────────────────────────────────── */
if (keyLogoutBtn) {
  keyLogoutBtn.addEventListener('click', async ()=>{
    _stopReverifyTimer();

    // Снимаем регистрацию устройства из Firestore
    const stored = await new Promise(res=>
      chrome.storage.local.get(
        ['licenseKey','licenseData','licenseDocName','_did'],
        d=>res(chrome.runtime.lastError?{}:d)
      )
    );
    if (stored.licenseDocName && stored.licenseData && stored._did) {
      try {
        await unregisterDevice(stored.licenseDocName, stored.licenseData, stored._did);
      } catch(_) {}
    }

    chrome.storage.local.remove(['licenseKey','licenseData','licenseToken','licenseDocName'],()=>{
      if (keyInput)       keyInput.value='';
      if (keyInfo)        keyInfo.classList.remove('show');
      if (keyLogoutBtn)   keyLogoutBtn.style.display='none';
      if (keyActivateBtn) keyActivateBtn.disabled=false;
      _setKeyStatus('');
      _showKeyScreen();
    });
  });
}

/* ── REVERIFY ───────────────────────────────────────────────── */
let _popupReverifyTimer=null;

function _startReverifyTimer() {
  _stopReverifyTimer();
  _popupReverifyTimer=setInterval(_popupReverify,60*1000);
}
function _stopReverifyTimer() {
  if (_popupReverifyTimer) { clearInterval(_popupReverifyTimer); _popupReverifyTimer=null; }
}

async function _popupReverify() {
  const stored=await new Promise(res=>
    chrome.storage.local.get(
      ['licenseKey','licenseData','licenseToken','_did'],
      d=>res(chrome.runtime.lastError?{}:d)
    )
  );
  const {licenseKey:key,licenseData:data,licenseToken:token,_did:deviceId}=stored;
  if (!key||!data||!token||!deviceId) {
    _stopReverifyTimer();
    _showKeyScreen('KEY EXPIRED — ENTER NEW KEY','error');
    return;
  }
  let ok=false;
  try { ok=await validateCachedSession(key,data,token,deviceId); } catch(_) {}
  if (!ok) {
    _stopReverifyTimer();
    chrome.storage.local.remove(['licenseKey','licenseData','licenseToken','licenseDocName']);
    _showKeyScreen('KEY EXPIRED / REVOKED — ENTER NEW KEY','error');
    if (keyInput&&key) keyInput.value=key;
  }
}

/* ── STARTUP ────────────────────────────────────────────────── */
_showKeyScreen();

(async function _init() {
  const deviceId = await getDeviceId();
  const stored=await new Promise(res=>
    chrome.storage.local.get(
      ['licenseKey','licenseData','licenseToken'],
      d=>res(chrome.runtime.lastError?{}:d)
    )
  );
  const {licenseKey:key,licenseData:data,licenseToken:token}=stored;
  if (!key||!data||!token) return;

  let ok=false;
  try { ok=await validateCachedSession(key,data,token,deviceId); } catch(_) {}

  if (ok) { _showMainUI(data); _loadMainSettings(); _startReverifyTimer(); }
  else {
    chrome.storage.local.remove(['licenseKey','licenseData','licenseToken','licenseDocName']);
    _showKeyScreen('SESSION EXPIRED — RE-ENTER KEY','error');
    if (keyInput&&key) keyInput.value=key;
  }
})();

/* ── SETTINGS ───────────────────────────────────────────────── */
const toggleEngine=$('toggle-engine'),toggleScroll=$('toggle-scroll');
const toggleGhost=$('toggle-ghost'),  togglePromo=$('toggle-promo');
const sliderScale=$('slider-scale'),  scaleVal=$('scale-val');

const pickers={
  accent:{picker:$('picker-accent'),hex:$('hex-accent'),preview:$('preview-accent')},
  bg:    {picker:$('picker-bg'),    hex:$('hex-bg'),    preview:$('preview-bg')},
  hud:   {picker:$('picker-hud'),   hex:$('hex-hud'),   preview:$('preview-hud')},
  text:  {picker:$('picker-text'),  hex:$('hex-text'),  preview:$('preview-text')},
};

let _currentHex=_themeToHex(DEFAULT_THEME),_saveTimer=null;

function _updatePickerUI(hexMap) {
  for (const [k,v] of Object.entries(hexMap)) {
    const p=pickers[k]; if (!p) continue;
    if (p.picker)  p.picker.value=v;
    if (p.hex)     p.hex.value=v;
    if (p.preview) p.preview.style.background=v;
  }
  _applyAccent(hexMap.accent); _applyBgVar(hexMap.bg);
}
function _saveTheme(hexMap) {
  clearTimeout(_saveTimer);
  _saveTimer=setTimeout(()=>chrome.storage.local.set({theme:_hexToTheme(hexMap)}),80);
}
function _onColorChange(key,hex) {
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return;
  _currentHex={..._currentHex,[key]:hex};
  const p=pickers[key];
  if (p) {
    if (p.preview) p.preview.style.background=hex;
    if (p.picker)  p.picker.value=hex;
    if (p.hex)     p.hex.value=hex;
  }
  if (key==='accent') _applyAccent(hex);
  if (key==='bg')     _applyBgVar(hex);
  _saveTheme(_currentHex);
}

for (const [k,p] of Object.entries(pickers)) {
  if (p.picker) p.picker.addEventListener('input',()=>_onColorChange(k,p.picker.value));
  if (p.hex) {
    p.hex.addEventListener('input',()=>{ if(/^#[0-9a-fA-F]{6}$/.test(p.hex.value)) _onColorChange(k,p.hex.value); });
    p.hex.addEventListener('blur', ()=>{ if(p.hex&&!/^#[0-9a-fA-F]{6}$/.test(p.hex.value)) p.hex.value=_currentHex[k]; });
  }
}

document.querySelectorAll('.preset-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const p=PRESETS[btn.dataset.preset]; if(!p) return;
    _currentHex={...p}; _updatePickerUI(_currentHex); _saveTheme(_currentHex);
  });
});

const resetBtn=$('reset-colors');
if (resetBtn) resetBtn.addEventListener('click',()=>{
  _currentHex=_themeToHex(DEFAULT_THEME); _updatePickerUI(_currentHex); _saveTheme(_currentHex);
});

document.querySelectorAll('.tab-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
    btn.classList.add('active');
    const panel=$('tab-'+btn.dataset.tab);
    if (panel) panel.classList.add('active');
  });
});

function _bindToggle(key,el) {
  if (!el) return;
  el.addEventListener('change',()=>chrome.storage.local.set({[key]:el.checked}));
}
_bindToggle('engine4K',  toggleEngine);
_bindToggle('autoScroll',toggleScroll);
_bindToggle('ghostMode', toggleGhost);
_bindToggle('autoPromo', togglePromo);

if (sliderScale) {
  sliderScale.addEventListener('input',()=>{
    const v=parseFloat(sliderScale.value);
    if (scaleVal) scaleVal.textContent=v.toFixed(2)+'x';
    chrome.storage.local.set({uiScale:v});
  });
}

function _loadMainSettings() {
  chrome.storage.local.get(
    ['autoScroll','engine4K','ghostMode','autoPromo','uiScale','theme'],
    (data)=>{
      if (chrome.runtime.lastError) return;
      if (toggleEngine) toggleEngine.checked=data.engine4K  !==undefined?data.engine4K  :true;
      if (toggleScroll) toggleScroll.checked=data.autoScroll!==undefined?data.autoScroll:true;
      if (toggleGhost)  toggleGhost.checked =data.ghostMode !==undefined?data.ghostMode :false;
      if (togglePromo)  togglePromo.checked =data.autoPromo !==undefined?data.autoPromo :true;
      const s=data.uiScale!==undefined?data.uiScale:1.0;
      if (sliderScale) sliderScale.value=s;
      if (scaleVal)    scaleVal.textContent=parseFloat(s).toFixed(2)+'x';
      if (data.theme)  _currentHex=_themeToHex({...DEFAULT_THEME,...data.theme});
      _updatePickerUI(_currentHex);
    }
  );
}

/* ── VIDEO PLAYER ───────────────────────────────────────────── */
const videoUrlInput=$('video-url-input'),videoLoadBtn=$('video-load-btn');
const videoMsg=$('video-msg'),videoPlaceholder=$('video-placeholder');
const popupVideo=$('popup-video'),videoControls=$('video-controls');
const progressFill=$('video-progress-fill'),progressThumb=$('video-progress-thumb');
const progressWrap=$('video-progress-wrap');
const vcPlay=$('vc-play'),vcStop=$('vc-stop'),vcRew=$('vc-rew'),vcFwd=$('vc-fwd');
const vcTime=$('vc-time'),vcSpeed=$('vc-speed'),vcMute=$('vc-mute');
const vcVolume=$('vc-volume'),vcLoop=$('vc-loop'),vcFs=$('vc-fs');

function _fmtTime(s) {
  if (!isFinite(s)||s<0) return '0:00';
  return Math.floor(s/60)+':'+Math.floor(s%60).toString().padStart(2,'0');
}
function _showMsg(t,type){ if(!videoMsg) return; videoMsg.textContent=t; videoMsg.className='video-msg show '+(type||''); }
function _hideMsg(){ if (videoMsg) videoMsg.className='video-msg'; }

function _loadVideo() {
  if (!videoUrlInput||!popupVideo) return;
  let raw=videoUrlInput.value.trim();
  if (!raw) { _showMsg('Enter URL','err'); return; }
  if (!/^https?:\/\//i.test(raw)) raw='https://'+raw;
  _showMsg('LOADING\u2026','info');
  popupVideo.style.display='none';
  if (videoPlaceholder) videoPlaceholder.style.display='flex';
  if (videoControls)    videoControls.classList.remove('visible');
  popupVideo.src=raw; popupVideo.load();
}

if (videoLoadBtn)  videoLoadBtn.addEventListener('click',_loadVideo);
if (videoUrlInput) videoUrlInput.addEventListener('keydown',e=>{ if(e.key==='Enter') _loadVideo(); });

if (popupVideo) {
  popupVideo.addEventListener('loadedmetadata',()=>{
    popupVideo.style.display='block';
    if (videoPlaceholder) videoPlaceholder.style.display='none';
    if (videoControls)    videoControls.classList.add('visible');
    _hideMsg(); popupVideo.play().catch(()=>{});
    if (vcPlay) vcPlay.textContent='\u23F8';
  });
  popupVideo.addEventListener('error',()=>{
    const c=popupVideo.error&&popupVideo.error.code;
    const m={1:'ABORTED',2:'NETWORK ERROR',3:'DECODE ERROR',4:'FORMAT NOT SUPPORTED'};
    _showMsg(m[c]||'LOAD FAILED','err');
    popupVideo.style.display='none';
    if (videoPlaceholder) videoPlaceholder.style.display='flex';
    if (videoControls)    videoControls.classList.remove('visible');
  });
  popupVideo.addEventListener('timeupdate',()=>{
    const d=popupVideo.duration||0,c=popupVideo.currentTime||0;
    const p=d>0?(c/d)*100:0;
    if (progressFill)  progressFill.style.width=p+'%';
    if (progressThumb) progressThumb.style.left=p+'%';
    if (vcTime)        vcTime.textContent=_fmtTime(c)+' / '+_fmtTime(d);
  });
  popupVideo.addEventListener('play', ()=>{ if(vcPlay) vcPlay.textContent='\u23F8'; });
  popupVideo.addEventListener('pause',()=>{ if(vcPlay) vcPlay.textContent='\u25B6'; });
  popupVideo.addEventListener('ended',()=>{ if(vcPlay&&!popupVideo.loop) vcPlay.textContent='\u25B6'; });
}

let _seeking=false;
function _seekTo(cx) {
  if (!popupVideo||!progressWrap) return;
  const r=progressWrap.getBoundingClientRect();
  const pct=Math.max(0,Math.min(1,(cx-r.left)/r.width));
  if (isFinite(popupVideo.duration)) popupVideo.currentTime=popupVideo.duration*pct;
}
if (progressWrap) {
  progressWrap.addEventListener('mousedown',e=>{ _seeking=true; _seekTo(e.clientX); });
  progressWrap.addEventListener('touchstart',e=>{ _seeking=true; _seekTo(e.touches[0].clientX); },{passive:true});
}
document.addEventListener('mousemove',e=>{ if(_seeking) _seekTo(e.clientX); });
document.addEventListener('mouseup',  ()=>{ _seeking=false; });
document.addEventListener('touchmove',e=>{ if(_seeking) _seekTo(e.touches[0].clientX); },{passive:true});
document.addEventListener('touchend', ()=>{ _seeking=false; });

if (vcPlay) vcPlay.addEventListener('click',()=>{
  if (!popupVideo) return;
  if (popupVideo.paused||popupVideo.ended) popupVideo.play().catch(()=>{});
  else popupVideo.pause();
});
if (vcStop) vcStop.addEventListener('click',()=>{
  if (!popupVideo) return;
  popupVideo.pause(); popupVideo.currentTime=0;
  if (vcPlay) vcPlay.textContent='\u25B6';
});
if (vcRew) vcRew.addEventListener('click',()=>{ if(popupVideo) popupVideo.currentTime=Math.max(0,popupVideo.currentTime-10); });
if (vcFwd) vcFwd.addEventListener('click',()=>{ if(popupVideo&&isFinite(popupVideo.duration)) popupVideo.currentTime=Math.min(popupVideo.duration,popupVideo.currentTime+10); });
if (vcSpeed) vcSpeed.addEventListener('change',()=>{ if(popupVideo) popupVideo.playbackRate=parseFloat(vcSpeed.value); });
if (vcVolume) vcVolume.addEventListener('input',()=>{
  if (!popupVideo) return;
  popupVideo.volume=parseFloat(vcVolume.value);
  popupVideo.muted=popupVideo.volume===0;
  if (vcMute) vcMute.textContent=popupVideo.muted?'\uD83D\uDD07':'\uD83D\uDD0A';
});
if (vcMute) vcMute.addEventListener('click',()=>{
  if (!popupVideo) return;
  popupVideo.muted=!popupVideo.muted;
  vcMute.textContent=popupVideo.muted?'\uD83D\uDD07':'\uD83D\uDD0A';
  if (!popupVideo.muted&&popupVideo.volume===0) { popupVideo.volume=0.5; if(vcVolume) vcVolume.value='0.5'; }
});
let _loopOn=false;
if (vcLoop) vcLoop.addEventListener('click',()=>{
  _loopOn=!_loopOn;
  if (popupVideo) popupVideo.loop=_loopOn;
  vcLoop.style.opacity=_loopOn?'1':'0.35';
});
if (vcFs) vcFs.addEventListener('click',()=>{
  if (!popupVideo) return;
  if      (popupVideo.requestFullscreen)       popupVideo.requestFullscreen().catch(()=>{});
  else if (popupVideo.webkitRequestFullscreen) popupVideo.webkitRequestFullscreen();
});
