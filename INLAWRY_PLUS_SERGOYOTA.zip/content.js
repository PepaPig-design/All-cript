'use strict';

/* ═══════════════════════════════════════════════════════════════
   INLINED CRYPTO  (content script не имеет доступа к popup JS)
   ═══════════════════════════════════════════════════════════════ */
const _CS_SALT = 'INLAWRY_SERGOYOTA_7_SALT_XK9M';

async function _cs_hmacSHA256(keyStr, dataStr) {
  try {
    const km = await crypto.subtle.importKey(
      'raw', new TextEncoder().encode(keyStr),
      { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const sig = await crypto.subtle.sign(
      'HMAC', km, new TextEncoder().encode(dataStr)
    );
    return Array.from(new Uint8Array(sig))
      .map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (_) { return ''; }
}

async function _cs_generateToken(keyStr, docData, deviceId) {
  const today   = new Date().toISOString().slice(0, 10);
  const payload = [
    keyStr,
    (docData && docData.expiry) || 'NONE',
    String(docData && docData.active),
    (docData && docData.owner)  || 'ANON',
    deviceId || 'NODEV',
    today,
  ].join('|');
  return _cs_hmacSHA256(_CS_SALT + keyStr, payload);
}

async function _cs_verifyToken(keyStr, docData, storedToken, deviceId) {
  if (!storedToken || typeof storedToken !== 'string') return false;
  if (!keyStr || !docData) return false;
  const expected = await _cs_generateToken(keyStr, docData, deviceId);
  if (!expected || expected.length !== storedToken.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) {
    diff |= expected.charCodeAt(i) ^ storedToken.charCodeAt(i);
  }
  return diff === 0;
}

/* ═══════════════════════════════════════════════════════════════
   INLINED FIREBASE  (для оверлея)
   ═══════════════════════════════════════════════════════════════ */
async function _cs_validateKey(userKey, deviceId) {
  const _FC = [
    'AIzaSyB4IdC3pz4pSGSCH5Ce-u_EYV1CzP9SgtY',
    'inlawry-void-keys',
    'keys',
    'key',
  ];

  const queryUrl =
    'https://firestore.googleapis.com/v1/projects/' + _FC[1] +
    '/databases/(default)/documents:runQuery?key=' + _FC[0];

  const body = {
    structuredQuery: {
      from: [{ collectionId: _FC[2] }],
      where: {
        fieldFilter: {
          field: { fieldPath: _FC[3] },
          op: 'EQUAL',
          value: { stringValue: userKey },
        },
      },
      limit: 1,
    },
  };

  let res;
  try {
    res = await fetch(queryUrl, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body),
      cache  : 'no-store',
    });
  } catch (e) {
    throw new Error('CONNECTION ERROR');
  }

  if (!res.ok) throw new Error('HTTP_' + res.status);

  const json = await res.json();
  if (!Array.isArray(json) || !json[0] || !json[0].document) {
    return { valid: false, reason: 'INVALID KEY', data: null, token: null, docName: null };
  }

  const rawFields = json[0].document.fields || {};
  const docName   = json[0].document.name;
  const data      = {};

  for (const [k, v] of Object.entries(rawFields)) {
    if      (v.stringValue    !== undefined) data[k] = v.stringValue;
    else if (v.booleanValue   !== undefined) data[k] = v.booleanValue;
    else if (v.integerValue   !== undefined) data[k] = parseInt(v.integerValue, 10);
    else if (v.doubleValue    !== undefined) data[k] = parseFloat(v.doubleValue);
    else if (v.timestampValue !== undefined) data[k] = v.timestampValue;
    else if (v.arrayValue     !== undefined) {
      data[k] = (v.arrayValue.values || []).map(item =>
        item.stringValue !== undefined ? item.stringValue : String(item)
      );
    }
    else data[k] = null;
  }

  if (data.active !== true) {
    return { valid: false, reason: 'KEY REVOKED', data, token: null, docName };
  }
  if (data.expiry) {
    const today  = new Date().toISOString().slice(0, 10);
    const expiry = String(data.expiry).slice(0, 10);
    if (today > expiry) {
      return { valid: false, reason: 'KEY EXPIRED (' + expiry + ')', data, token: null, docName };
    }
  }

  // Проверка max_devices
  const maxDev  = (data.max_devices !== undefined && data.max_devices !== null)
    ? parseInt(data.max_devices, 10) : null;
  let devices   = Array.isArray(data.devices) ? [...data.devices] : [];

  if (!devices.includes(deviceId)) {
    if (maxDev !== null && !isNaN(maxDev) && maxDev > 0 && devices.length >= maxDev) {
      return {
        valid: false,
        reason: 'DEVICE LIMIT REACHED (' + devices.length + '/' + maxDev + ')',
        data, token: null, docName,
      };
    }
    // Регистрируем устройство через PATCH
    devices.push(deviceId);
    try {
      const patchUrl = 'https://firestore.googleapis.com/v1/' + docName +
        '?key=' + _FC[0] + '&updateMask.fieldPaths=devices';
      await fetch(patchUrl, {
        method : 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          fields: {
            devices: {
              arrayValue: { values: devices.map(d => ({ stringValue: d })) },
            },
          },
        }),
        cache: 'no-store',
      });
    } catch (_) { /* Не блокируем активацию если PATCH упал */ }
  }

  const token = await _cs_generateToken(userKey, data, deviceId);
  return { valid: true, reason: 'OK', data, token, docName };
}

/* ═══════════════════════════════════════════════════════════════
   DEVICE ID helper (content script версия)
   ═══════════════════════════════════════════════════════════════ */
function _cs_getDeviceId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['_did'], (data) => {
      if (!chrome.runtime.lastError && data._did && data._did.length >= 16) {
        resolve(data._did);
        return;
      }
      const arr = new Uint8Array(16);
      crypto.getRandomValues(arr);
      const id = Array.from(arr).map(b => b.toString(16).padStart(2,'0')).join('')
               + '_' + Date.now().toString(36);
      chrome.storage.local.set({ _did: id }, () => resolve(id));
    });
  });
}

/* ═══════════════════════════════════════════════════════════════
   STATE
   ═══════════════════════════════════════════════════════════════ */
const _S = {
  autoScroll    : true,
  engine4K      : true,
  ghostMode     : false,
  autoPromo     : true,
  uiScale       : 1.0,
  recording     : false,
  mediaRecorder : null,
  recordedChunks: [],
  sourceVideo   : null,
  overlayActive : false,
  deviceId      : null,
  theme: {
    accentR:255, accentG:26,  accentB:26,
    bgR:10,      bgG:0,       bgB:0,
    hudR:8,      hudG:0,      hudB:0,
    textR:204,   textG:204,   textB:204,
  },
  licensed: false,
};

const REVERIFY_INTERVAL = 60 * 1000;
let _reverifyTimer = null;

/* ═══════════════════════════════════════════════════════════════
   LICENSE VERIFY
   ═══════════════════════════════════════════════════════════════ */
async function _verifyLicense() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      ['licenseKey', 'licenseData', 'licenseToken', '_did'],
      async (stored) => {
        if (chrome.runtime.lastError) { resolve(false); return; }
        const {
          licenseKey  : key,
          licenseData : data,
          licenseToken: token,
          _did        : deviceId,
        } = stored;
        if (!key || !data || !token || !deviceId) { resolve(false); return; }
        try {
          resolve(await _cs_verifyToken(key, data, token, deviceId));
        } catch (_) { resolve(false); }
      }
    );
  });
}

async function _startVerification() {
  // Получаем deviceId
  _S.deviceId = await _cs_getDeviceId();

  let ok = false;
  try { ok = await _verifyLicense(); } catch (_) {}
  _S.licensed = ok;
  if (ok) { _activateEngine(); _scheduleReverify(); }
}

function _scheduleReverify() {
  if (_reverifyTimer) clearInterval(_reverifyTimer);
  _reverifyTimer = setInterval(async () => {
    let ok = false;
    try { ok = await _verifyLicense(); } catch (_) {}
    if (!ok && _S.licensed) {
      _S.licensed = false;
      _deactivateEngine();
      try {
        chrome.storage.local.remove(
          ['licenseKey', 'licenseData', 'licenseToken'], () => {}
        );
      } catch (_) {}
      _showExpiredOverlay();
    }
  }, REVERIFY_INTERVAL);
}

/* ═══════════════════════════════════════════════════════════════
   EXPIRED OVERLAY
   ═══════════════════════════════════════════════════════════════ */
function _showExpiredOverlay() {
  if (document.getElementById('inlawry-expired-overlay')) return;

  _S.overlayActive = true;

  if (_S.mediaRecorder && _S.mediaRecorder.state !== 'inactive') {
    try { _S.mediaRecorder.stop(); } catch (_) {}
  }
  _S.recording = false;

  const ov = document.createElement('div');
  ov.id = 'inlawry-expired-overlay';
  ov.style.cssText = [
    'position:fixed', 'inset:0', 'z-index:2147483647',
    'background:rgba(0,0,0,0.96)',
    'display:flex', 'align-items:center', 'justify-content:center',
    'backdrop-filter:blur(10px)',
    '-webkit-backdrop-filter:blur(10px)',
    'font-family:Courier New,monospace',
    'pointer-events:all',
  ].join('!important;') + '!important';

  ov.innerHTML = `
    <div id="_ib">
      <div id="_il">&#9632; INLAWRY+SERGOYOTA</div>
      <div id="_it">KEY EXPIRED / REVOKED</div>
      <div id="_is">Your license is no longer valid.<br>Enter a new key to continue.</div>
      <input id="_ii" type="text" placeholder="VOID-XXXX-XXXX-XXXX"
             maxlength="24" autocomplete="off" spellcheck="false"/>
      <button id="_ib2">&#9654;&nbsp;ACTIVATE NEW KEY</button>
      <div id="_ist"></div>
    </div>`;

  document.documentElement.appendChild(ov);

  if (!document.getElementById('_ov_style')) {
    const st = document.createElement('style');
    st.id = '_ov_style';
    st.textContent = `
      @keyframes _ov_in   {from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}
      @keyframes _ov_pulse{0%,100%{text-shadow:0 0 10px rgba(255,26,26,.6)}50%{text-shadow:0 0 22px rgba(255,26,26,1),0 0 40px rgba(255,26,26,.4)}}
      @keyframes _ov_shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}40%{transform:translateX(8px)}60%{transform:translateX(-5px)}80%{transform:translateX(5px)}}
      #_ii:focus{border-color:rgba(255,26,26,.7)!important;box-shadow:0 0 14px rgba(255,26,26,.2)!important;outline:none!important}
      #_ib2:hover:not(:disabled){background:linear-gradient(135deg,rgba(255,26,26,.3),rgba(255,26,26,.5))!important;box-shadow:0 0 18px rgba(255,26,26,.35)!important}
      #_ib2:disabled{opacity:.45!important;cursor:not-allowed!important}
    `;
    document.documentElement.appendChild(st);
  }

  const box = ov.querySelector('#_ib');
  box.style.cssText = [
    'background:linear-gradient(135deg,#0d0000,#080000)',
    'border:1px solid rgba(255,26,26,0.55)',
    'border-radius:14px', 'padding:32px 30px 26px',
    'width:330px', 'max-width:90vw',
    'display:flex', 'flex-direction:column', 'align-items:center', 'gap:16px',
    'box-shadow:0 0 60px rgba(255,26,26,0.3),0 8px 40px rgba(0,0,0,0.9)',
    'animation:_ov_in 0.3s ease',
  ].join(';');

  ov.querySelector('#_il').style.cssText =
    'font-size:13px;font-weight:900;color:#ff1a1a;letter-spacing:2px;animation:_ov_pulse 2s ease-in-out infinite';
  ov.querySelector('#_it').style.cssText =
    'font-size:17px;font-weight:900;color:#ff4444;letter-spacing:3px;text-align:center';
  ov.querySelector('#_is').style.cssText =
    'font-size:10px;color:#555;letter-spacing:1px;text-align:center;line-height:1.8';

  const inp = ov.querySelector('#_ii');
  inp.style.cssText = [
    'width:100%', 'background:#0e0e0e',
    'border:1px solid rgba(255,26,26,0.3)', 'border-radius:7px',
    'padding:11px 14px',
    'font-family:Courier New,monospace', 'font-size:13px',
    'color:#eee', 'letter-spacing:2px', 'text-align:center',
    'text-transform:uppercase', 'box-sizing:border-box',
    'transition:border-color 0.2s,box-shadow 0.2s',
  ].join(';');

  const btn = ov.querySelector('#_ib2');
  btn.style.cssText = [
    'width:100%', 'padding:11px',
    'background:linear-gradient(135deg,rgba(255,26,26,0.18),rgba(255,26,26,0.35))',
    'border:1px solid rgba(255,26,26,0.6)', 'border-radius:7px',
    'font-family:Courier New,monospace', 'font-size:12px',
    'font-weight:900', 'letter-spacing:3px', 'color:#ff1a1a',
    'cursor:pointer', 'transition:all 0.2s',
  ].join(';');

  const st2 = ov.querySelector('#_ist');
  st2.style.cssText =
    'font-size:10px;letter-spacing:1px;text-align:center;min-height:18px;color:#555;transition:color 0.2s';

  inp.addEventListener('input', () => {
    inp.value = inp.value.toUpperCase().replace(/[^A-Z0-9\-]/g, '');
  });

  // Блокируем всё снаружи инпута
  const _keyBlocker = (e) => {
    if (e.target !== inp) { e.stopImmediatePropagation(); e.preventDefault(); }
  };
  const _scrollBlocker = (e) => { e.stopImmediatePropagation(); };
  document.addEventListener('keydown',    _keyBlocker,    true);
  document.addEventListener('keyup',      _keyBlocker,    true);
  document.addEventListener('scroll',     _scrollBlocker, true);
  document.addEventListener('touchstart', _scrollBlocker, { capture:true, passive:false });
  document.addEventListener('touchmove',  _scrollBlocker, { capture:true, passive:false });

  // Shake при клике на фон
  ov.addEventListener('click', (e) => {
    if (e.target === ov) {
      box.style.animation = 'none';
      void box.offsetWidth;
      box.style.animation = '_ov_shake 0.4s ease';
    }
  });

  async function _tryActivate() {
    const raw = inp.value.trim().toUpperCase();
    if (!raw || raw.length < 6) {
      st2.textContent = 'ENTER A VALID KEY';
      st2.style.color = '#ff4444';
      inp.style.animation = 'none'; void inp.offsetWidth;
      inp.style.animation = '_ov_shake 0.4s ease';
      return;
    }

    btn.disabled        = true;
    st2.textContent     = 'CHECKING\u2026';
    st2.style.color     = '#ffaa22';
    inp.style.borderColor = 'rgba(255,170,34,0.5)';

    let result;
    try {
      const devId = _S.deviceId || await _cs_getDeviceId();
      result = await _cs_validateKey(raw, devId);
    } catch (e) {
      st2.textContent   = 'CONNECTION ERROR — RETRY';
      st2.style.color   = '#ff4444';
      inp.style.borderColor = 'rgba(255,26,26,0.3)';
      btn.disabled      = false;
      return;
    }

    if (result && result.valid) {
      st2.textContent     = '\u2714 KEY ACTIVATED';
      st2.style.color     = '#44ff88';
      inp.style.borderColor = 'rgba(68,255,136,0.5)';

      chrome.storage.local.set(
        {
          licenseKey    : raw,
          licenseData   : result.data,
          licenseToken  : result.token,
          licenseDocName: result.docName,
        },
        () => {
          if (chrome.runtime.lastError) {
            st2.textContent = 'STORAGE ERROR';
            st2.style.color = '#ff4444';
            btn.disabled    = false;
            return;
          }

          _S.licensed      = true;
          _S.overlayActive = false;

          document.removeEventListener('keydown',    _keyBlocker,    true);
          document.removeEventListener('keyup',      _keyBlocker,    true);
          document.removeEventListener('scroll',     _scrollBlocker, true);
          document.removeEventListener('touchstart', _scrollBlocker, true);
          document.removeEventListener('touchmove',  _scrollBlocker, true);

          setTimeout(() => {
            try { ov.remove(); } catch (_) {}
            try { document.getElementById('_ov_style')?.remove(); } catch (_) {}
          }, 700);

          _activateEngine();
          _scheduleReverify();
        }
      );
    } else {
      const reason = (result && result.reason) || 'UNKNOWN ERROR';
      st2.textContent   = reason;
      st2.style.color   = '#ff4444';
      inp.style.borderColor = 'rgba(255,26,26,0.5)';
      inp.style.animation = 'none'; void inp.offsetWidth;
      inp.style.animation = '_ov_shake 0.4s ease';
      btn.disabled      = false;
    }
  }

  btn.addEventListener('click', _tryActivate);
  inp.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') _tryActivate();
  });

  setTimeout(() => { try { inp.focus(); } catch (_) {} }, 120);
}

/* ═══════════════════════════════════════════════════════════════
   ENGINE
   ═══════════════════════════════════════════════════════════════ */
function _activateEngine() {
  _loadSettings(() => {
    _buildHUD();
    _applyTheme();
    _applyEngineSettings();
    _applyGhostMode();
    _applyUIScale();
    _initVideoObserver();
    if (_isUploadPage()) { _buildStallInjectorUI(); _tryAutoPromo(); }
  });
}

function _deactivateEngine() {
  _stopRAF();
  ['inlawry-hud','inlawry-theme-sheet','inlawry-ghost-sheet','inlawry-stall-panel']
    .forEach(id => { try { document.getElementById(id)?.remove(); } catch (_) {} });
  if (_S.mediaRecorder && _S.mediaRecorder.state !== 'inactive') {
    try { _S.mediaRecorder.stop(); } catch (_) {}
  }
  _S.recording = false;
  if (_reverifyTimer) { clearInterval(_reverifyTimer); _reverifyTimer = null; }
}

/* ── STORAGE LISTENER ───────────────────────────────────────── */
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.licenseToken || changes.licenseKey || changes.licenseData) {
    _startVerification(); return;
  }
  if (!_S.licensed || _S.overlayActive) return;
  for (const [k, { newValue }] of Object.entries(changes)) {
    if (k === 'theme') { _S.theme = { ..._S.theme, ...newValue }; _applyTheme(); }
    else if (k in _S)  { _S[k] = newValue; }
  }
  _applyEngineSettings(); _applyGhostMode(); _applyUIScale(); _updateHUD();
});

/* ── THEME ──────────────────────────────────────────────────── */
function _applyTheme() {
  if (_S.overlayActive) return;
  const t = _S.theme;
  const accent = `${t.accentR},${t.accentG},${t.accentB}`;
  const hud    = `${t.hudR},${t.hudG},${t.hudB}`;
  const txt    = `${t.textR},${t.textG},${t.textB}`;
  let sheet = document.getElementById('inlawry-theme-sheet');
  if (!sheet) {
    sheet = document.createElement('style');
    sheet.id = 'inlawry-theme-sheet';
    document.documentElement.appendChild(sheet);
  }
  sheet.textContent = `
    #inlawry-hud{background:rgba(${hud},0.60)!important;border-color:rgba(${accent},0.35)!important}
    .hud-val.on{color:rgb(${accent})!important;text-shadow:0 0 6px rgba(${accent},0.55)!important}
    .hud-brand{color:rgb(${accent})!important;border-top-color:rgba(${accent},0.25)!important}
    .inlawry-watermark{border-left-color:rgba(${accent},0.7)!important;color:rgba(${txt},0.85)!important}
    #inlawry-stall-panel{border-color:rgba(${accent},0.38)!important}
    .stall-logo{color:rgb(${accent})!important}
    .stall-row label{color:rgb(${accent})!important}
    .stall-btn.primary{color:rgb(${accent})!important;border-color:rgba(${accent},0.4)!important}
    .stall-progress-fill{background:linear-gradient(90deg,rgba(${accent},0.5),rgb(${accent}))!important}
    .inlawry-toast-ok{border-color:rgba(${accent},0.5)!important;color:rgb(${accent})!important}
  `;
}

/* ── SETTINGS ───────────────────────────────────────────────── */
function _loadSettings(cb) {
  try {
    chrome.storage.local.get(
      ['autoScroll','engine4K','ghostMode','autoPromo','uiScale','theme'],
      (data) => {
        if (chrome.runtime.lastError) { cb(); return; }
        if (data.autoScroll !== undefined) _S.autoScroll = data.autoScroll;
        if (data.engine4K   !== undefined) _S.engine4K   = data.engine4K;
        if (data.ghostMode  !== undefined) _S.ghostMode  = data.ghostMode;
        if (data.autoPromo  !== undefined) _S.autoPromo  = data.autoPromo;
        if (data.uiScale    !== undefined) _S.uiScale    = data.uiScale;
        if (data.theme) _S.theme = { ..._S.theme, ...data.theme };
        cb();
      }
    );
  } catch (_) { cb(); }
}

/* ── QUALITY ENGINE ─────────────────────────────────────────── */
function _spoofConnection() {
  try {
    if (!('connection' in navigator)) return;
    const fake = {
      downlink:100, rtt:5, effectiveType:'4g', saveData:false,
      addEventListener:()=>{}, removeEventListener:()=>{}, dispatchEvent:()=>true,
    };
    Object.defineProperty(navigator, 'connection', { get:()=>fake, configurable:true });
  } catch (_) {}
}

function _accelerateVideo(v) {
  if (!v || v.dataset.inlawryAccel) return;
  v.dataset.inlawryAccel     = '1';
  v.style.transform          = 'translateZ(0)';
  v.style.webkitTransform    = 'translateZ(0)';
  v.style.willChange         = 'transform';
  v.style.imageRendering     = 'crisp-edges';
  v.style.backfaceVisibility = 'hidden';
}

let _rafHandle = null;
function _startRAF() {
  if (_rafHandle) return;
  let last = 0;
  function tick(ts) {
    if (ts - last >= 1000 / 120) last = ts;
    _rafHandle = requestAnimationFrame(tick);
  }
  _rafHandle = requestAnimationFrame(tick);
}
function _stopRAF() {
  if (_rafHandle) { cancelAnimationFrame(_rafHandle); _rafHandle = null; }
}

function _applyEngineSettings() {
  if (_S.overlayActive) return;
  if (_S.engine4K) { _startRAF(); document.querySelectorAll('video').forEach(_accelerateVideo); }
  else _stopRAF();
}

/* ── HUD ────────────────────────────────────────────────────── */
function _buildHUD() {
  if (_S.overlayActive || document.getElementById('inlawry-hud')) return;
  const hud = document.createElement('div');
  hud.id = 'inlawry-hud';
  hud.innerHTML = `
    <div class="hud-row" id="hud-engine">ENGINE <span class="hud-val on">4K</span></div>
    <div class="hud-row" id="hud-scroll">SCROLL <span class="hud-val on">ON</span></div>
    <div class="hud-row" id="hud-ghost">GHOST  <span class="hud-val off">OFF</span></div>
    <div class="hud-row hud-brand">@INLAWRY+SERGOYOTA</div>`;
  document.documentElement.appendChild(hud);
  _updateHUD();
}

function _updateHUD() {
  if (_S.overlayActive) return;
  const rows = {
    'hud-engine': [_S.engine4K   ? '4K' : 'OFF', _S.engine4K],
    'hud-scroll': [_S.autoScroll ? 'ON' : 'OFF', _S.autoScroll],
    'hud-ghost' : [_S.ghostMode  ? 'ON' : 'OFF', _S.ghostMode],
  };
  for (const [id, [txt, on]] of Object.entries(rows)) {
    const el = document.getElementById(id); if (!el) continue;
    const sp = el.querySelector('.hud-val');
    if (sp) { sp.textContent = txt; sp.className = 'hud-val ' + (on ? 'on' : 'off'); }
  }
}

/* ── GHOST MODE ─────────────────────────────────────────────── */
const _GHOST_SEL = [
  '[data-e2e="browse-username"]','[data-e2e="video-desc"]',
  '[data-e2e="like-container"]', '[data-e2e="comment-icon"]',
  '[data-e2e="share-icon"]',     'header',
  '[class*="DivHeader"]',        '[class*="SpanUniqueId"]',
  '[class*="action-bar"]',       '[class*="ActionBar"]',
  '[class*="SideBar"]',
].join(',');

function _applyGhostMode() {
  if (_S.overlayActive) return;
  let s = document.getElementById('inlawry-ghost-sheet');
  if (_S.ghostMode) {
    if (!s) {
      s = document.createElement('style');
      s.id = 'inlawry-ghost-sheet';
      s.textContent = `${_GHOST_SEL}{opacity:0!important;pointer-events:none!important;transition:opacity 0.35s ease!important}`;
      document.documentElement.appendChild(s);
    }
  } else { if (s) s.remove(); }
}

/* ── UI SCALE ───────────────────────────────────────────────── */
function _applyUIScale() {
  if (_S.overlayActive) return;
  try { document.body.style.zoom = String(_S.uiScale); } catch (_) {}
}

/* ── WATERMARK ──────────────────────────────────────────────── */
const _WM_TEXT  = 'HQ_VERIFIED // @INLAWRY+SERGOYOTA';
const _wmVideos = new WeakSet();

function _addWatermark(v) {
  if (_S.overlayActive || !v || _wmVideos.has(v)) return;
  _wmVideos.add(v);
  const c = v.closest('[class*="DivContainer"]')
           || v.closest('[class*="video-feed"]')
           || v.parentElement;
  if (!c || c.querySelector('.inlawry-watermark')) return;
  try {
    if (getComputedStyle(c).position === 'static') c.style.position = 'relative';
    const wm = document.createElement('div');
    wm.className   = 'inlawry-watermark';
    wm.textContent = _WM_TEXT;
    c.appendChild(wm);
  } catch (_) {}
}

/* ── AUTO-SCROLL ────────────────────────────────────────────── */
function _attachAutoScroll(v) {
  if (!v || v.dataset.inlawryScroll) return;
  v.dataset.inlawryScroll = '1';
  v.addEventListener('ended', () => {
    if (!_S.autoScroll || !_S.licensed || _S.overlayActive) return;
    try {
      const btn = document.querySelector('[data-e2e="arrow-right"]');
      if (btn) setTimeout(() => btn.click(), 300);
    } catch (_) {}
  });
}

/* ── VIDEO OBSERVER ─────────────────────────────────────────── */
function _processVideo(v) {
  if (_S.overlayActive || !v) return;
  if (_S.engine4K) _accelerateVideo(v);
  _addWatermark(v);
  _attachAutoScroll(v);
}

function _initVideoObserver() {
  document.querySelectorAll('video').forEach(_processVideo);
  new MutationObserver((muts) => {
    if (_S.overlayActive) return;
    for (const m of muts) {
      for (const n of m.addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.tagName === 'VIDEO') _processVideo(n);
        else if (n.querySelectorAll) n.querySelectorAll('video').forEach(_processVideo);
      }
    }
  }).observe(document.documentElement, { childList:true, subtree:true });
}

/* ── HOTKEY ─────────────────────────────────────────────────── */
document.addEventListener('keydown', (e) => {
  if (!_S.licensed || _S.overlayActive) return;
  const tag = e.target && e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA') return;
  if (e.key === 'c' || e.key === 'C') {
    _S.ghostMode = !_S.ghostMode;
    chrome.storage.local.set({ ghostMode: _S.ghostMode });
    _applyGhostMode(); _updateHUD();
  }
});

/* ── UPLOAD PAGE ────────────────────────────────────────────── */
const _CAPTION_TEXT =
  '\uD83D\uDD34 HQ_VERIFIED // @INLAWRY+SERGOYOTA\n' +
  '#INLAWRY #SERGOYOTA #4K #VOID_QUALITY #HQ_VERIFIED\n' +
  '\u2726 Infected by @inlawry x @sergoyota \u2726';

const _CAPTION_SELS = [
  '[data-e2e="upload-caption"]',
  '.public-DraftEditor-content',
  '[contenteditable="true"].notranslate',
  '[class*="DraftEditor-content"]',
  '[class*="caption-input"]',
  '[contenteditable="true"][class*="caption"]',
  'div[contenteditable="true"]',
];

function _isUploadPage() { return location.pathname.startsWith('/upload'); }

function _tryAutoPromo() {
  if (!_S.autoPromo || _S.overlayActive) return;
  let retries = 0;
  const MAX = 40, DELAY = 500;

  function findEl() {
    for (const sel of _CAPTION_SELS) {
      try {
        const el = document.querySelector(sel);
        if (el && !el.dataset.inlawryPromo) return el;
      } catch (_) {}
    }
    return null;
  }

  function fill(el) {
    try {
      el.dataset.inlawryPromo = '1'; el.focus();
      if (el.tagName === 'TEXTAREA') {
        el.value = _CAPTION_TEXT;
        el.dispatchEvent(new Event('input',  { bubbles:true }));
        el.dispatchEvent(new Event('change', { bubbles:true }));
        return;
      }
      try {
        document.execCommand('selectAll', false, null);
        document.execCommand('delete',    false, null);
      } catch (_) { el.textContent = ''; }
      const lines = _CAPTION_TEXT.split('\n');
      try {
        for (let i = 0; i < lines.length; i++) {
          document.execCommand('insertText', false, lines[i]);
          if (i < lines.length - 1) {
            el.dispatchEvent(new KeyboardEvent('keydown',
              { key:'Enter', code:'Enter', keyCode:13, bubbles:true, cancelable:true }));
            document.execCommand('insertParagraph', false, null);
          }
        }
      } catch (_) {
        el.textContent = _CAPTION_TEXT;
        el.dispatchEvent(new Event('input', { bubbles:true }));
      }
    } catch (_) {}
  }

  function attempt() {
    if (_S.overlayActive) return;
    const el = findEl();
    if (el) {
      fill(el);
      setTimeout(() => {
        const content = el.textContent || el.value || '';
        if (!content.includes('INLAWRY') && retries < MAX) {
          delete el.dataset.inlawryPromo; retries++;
          setTimeout(attempt, DELAY);
        } else { _showToast('\u2714 CAPTION INJECTED', 'ok'); }
      }, 300);
    } else if (retries < MAX) { retries++; setTimeout(attempt, DELAY); }
  }
  setTimeout(attempt, 800);
}

function _showToast(msg, type) {
  if (_S.overlayActive) return;
  try {
    const t = document.createElement('div');
    t.className   = 'inlawry-toast inlawry-toast-' + (type||'ok');
    t.textContent = msg;
    document.documentElement.appendChild(t);
    setTimeout(() => { try { t.remove(); } catch (_) {} }, 3000);
  } catch (_) {}
}

/* ── STALL INJECTOR ─────────────────────────────────────────── */
function _buildStallInjectorUI() {
  if (_S.overlayActive || document.getElementById('inlawry-stall-panel')) return;
  const p = document.createElement('div');
  p.id = 'inlawry-stall-panel';
  p.innerHTML = `
    <div class="stall-header">
      <span class="stall-logo">INLAWRY+SERGOYOTA</span>
      <span class="stall-sub">STALL INJECTOR v7</span>
    </div>
    <div class="stall-body">
      <div class="stall-row">
        <label>Source Video</label>
        <input type="file" id="stall-file-input" accept="video/*"/>
      </div>
      <div class="stall-row">
        <label>Status</label>
        <span id="stall-status" class="stall-status">IDLE</span>
      </div>
      <div class="stall-row">
        <label>Progress</label>
        <div class="stall-progress-bg">
          <div id="stall-progress-bar" class="stall-progress-fill" style="width:0%"></div>
        </div>
        <span id="stall-pct">0%</span>
      </div>
      <div class="stall-row stall-btns">
        <button id="stall-start-btn" class="stall-btn primary">&#9654; ENCODE</button>
        <button id="stall-stop-btn"  class="stall-btn danger" disabled>&#9632; STOP</button>
      </div>
      <a id="stall-download-link" class="stall-dl-link" style="display:none">
        &#8595; Download Injected Video
      </a>
    </div>`;
  document.documentElement.appendChild(p);
  _bindStallEvents(p);
}

function _bindStallEvents(panel) {
  const fi  = panel.querySelector('#stall-file-input');
  const sb  = panel.querySelector('#stall-start-btn');
  const xb  = panel.querySelector('#stall-stop-btn');
  const st  = panel.querySelector('#stall-status');
  const pb  = panel.querySelector('#stall-progress-bar');
  const pct = panel.querySelector('#stall-pct');
  const dl  = panel.querySelector('#stall-download-link');
  if (!fi||!sb||!xb||!st||!pb||!pct||!dl) return;

  const setSt  = (m,c) => { st.textContent=m; st.className='stall-status '+(c||''); };
  const setPct = (v)   => { pb.style.width=v+'%'; pct.textContent=Math.round(v)+'%'; };

  sb.addEventListener('click', async () => {
    if (_S.overlayActive) return;
    const file = fi.files && fi.files[0];
    if (!file) { setSt('No file selected','warn'); return; }
    if (_S.recording) return;
    dl.style.display='none'; setPct(0);
    sb.disabled=true; xb.disabled=false;
    _S.recording=true; _S.recordedChunks=[];
    await _runStallInjector(file, {
      onStatus  : setSt,
      onProgress: setPct,
      onDone: (blob) => {
        _S.recording=false; sb.disabled=false; xb.disabled=true;
        setSt('DONE','ok'); setPct(100);
        dl.href=URL.createObjectURL(blob);
        dl.download='INLAWRY_SERGOYOTA_INJECTED.webm';
        dl.style.display='block';
      },
      onError: (err) => {
        _S.recording=false; sb.disabled=false; xb.disabled=true;
        setSt('ERR: '+err,'error');
      },
    });
  });

  xb.addEventListener('click', () => {
    if (_S.mediaRecorder && _S.mediaRecorder.state!=='inactive') {
      try { _S.mediaRecorder.stop(); } catch (_) {}
    }
    _S.recording=false; xb.disabled=true; sb.disabled=false;
    setSt('STOPPED','warn');
  });
}

async function _runStallInjector(file, { onStatus, onProgress, onDone, onError }) {
  onStatus('LOADING\u2026','info');
  const video = document.createElement('video');
  video.muted=true; video.playsInline=true; video.preload='auto';
  let objectUrl='';
  try { objectUrl=URL.createObjectURL(file); video.src=objectUrl; }
  catch(e) { onError('FileURL: '+e.message); return; }
  video.style.cssText='position:fixed;opacity:0;pointer-events:none;top:-9999px;width:1px;height:1px';
  document.body.appendChild(video);
  _S.sourceVideo=video;

  try {
    await new Promise((res,rej) => {
      const t=setTimeout(()=>rej(new Error('Metadata timeout')),15000);
      video.onloadedmetadata=()=>{ clearTimeout(t); res(); };
      video.onerror=()=>{ clearTimeout(t); rej(new Error('Metadata failed')); };
      video.load();
    });
  } catch(e) {
    onError(e.message);
    try { video.remove(); } catch(_) {}
    try { URL.revokeObjectURL(objectUrl); } catch(_) {}
    return;
  }

  const duration=video.duration, vw=video.videoWidth||1280, vh=video.videoHeight||720;
  if (!isFinite(duration)||duration<=0) {
    onError('Invalid duration');
    try { video.remove(); } catch(_) {}
    try { URL.revokeObjectURL(objectUrl); } catch(_) {}
    return;
  }

  onStatus(`${vw}x${vh} | ${duration.toFixed(2)}s`,'info');
  const canvas=document.createElement('canvas');
  canvas.width=vw; canvas.height=vh;
  const ctx=canvas.getContext('2d');
  if (!ctx) { onError('Canvas failed'); video.remove(); URL.revokeObjectURL(objectUrl); return; }

  let stream;
  try { stream=canvas.captureStream(60); }
  catch(e) { onError('captureStream: '+e.message); video.remove(); URL.revokeObjectURL(objectUrl); return; }

  const mime=MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
    ?'video/webm;codecs=vp9':'video/webm';
  let rec;
  try { rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:80000000}); }
  catch(e) { onError('MediaRecorder: '+e.message); video.remove(); URL.revokeObjectURL(objectUrl); return; }

  _S.mediaRecorder=rec; _S.recordedChunks=[];
  rec.ondataavailable=(e)=>{ if(e.data&&e.data.size>0) _S.recordedChunks.push(e.data); };
  rec.onstop=()=>{
    onDone(new Blob(_S.recordedChunks,{type:mime}));
    try { video.remove(); } catch(_) {}
    try { URL.revokeObjectURL(objectUrl); } catch(_) {}
  };
  rec.onerror=(e)=>onError('Rec: '+(e.error||'unknown'));
  rec.start(100);
  onStatus('RECORDING\u2026','info');

  try { await video.play(); }
  catch(e) {
    onError('Play: '+e.message);
    try { rec.stop(); } catch(_) {}
    try { video.remove(); } catch(_) {}
    try { URL.revokeObjectURL(objectUrl); } catch(_) {}
    return;
  }

  let lastNoise=0, noisePending=false;
  async function injectNoise() {
    if (noisePending) return; noisePending=true;
    try { video.pause(); } catch(_) {}
    for (let f=0;f<5;f++) {
      try {
        const id=ctx.createImageData(vw,vh); const d=id.data;
        for (let i=0;i<d.length;i+=4) {
          d[i]=(Math.random()*255)|0; d[i+1]=(Math.random()*255)|0;
          d[i+2]=(Math.random()*255)|0; d[i+3]=(Math.random()*80+20)|0;
        }
        ctx.putImageData(id,0,0);
      } catch(_) {}
      await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    }
    try { video.play().catch(()=>{}); } catch(_) {}
    noisePending=false;
  }

  await new Promise((resolve) => {
    let done=false;
    function frame(ts) {
      if (done||!_S.recording) {
        if (!done&&rec.state!=='inactive') try { rec.stop(); } catch(_) {}
        resolve(); return;
      }
      if (video.currentTime>=duration-0.05||video.ended) {
        if (rec.state!=='inactive') try { rec.stop(); } catch(_) {}
        done=true; resolve(); return;
      }
      try { ctx.drawImage(video,0,0,vw,vh); } catch(_) {}
      onProgress((video.currentTime/duration)*100);
      if (ts-lastNoise>=1000) { lastNoise=ts; injectNoise().catch(()=>{}); }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    video.addEventListener('ended',()=>{
      if (!done) {
        if(rec.state!=='inactive') try{rec.stop();}catch(_){}
        done=true; resolve();
      }
    },{once:true});
  });
}

/* ── SPA ROUTE WATCHER ──────────────────────────────────────── */
let _lastPath = location.pathname;
new MutationObserver(() => {
  if (location.pathname !== _lastPath) {
    _lastPath = location.pathname;
    if (_S.licensed && !_S.overlayActive && _isUploadPage()) {
      _buildStallInjectorUI(); _tryAutoPromo();
    }
  }
}).observe(document.body || document.documentElement, { childList:true, subtree:true });

/* ── BOOTSTRAP ──────────────────────────────────────────────── */
function _boot() { _spoofConnection(); _startVerification(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _boot);
else _boot();
