'use strict';

/* ── CRYPTO ── */
const _CS_SALT = 'INLAWRY_SERGOYOTA_7_SALT_XK9M';

async function _cs_hmacSHA256(keyStr, dataStr) {
  try {
    const km = await crypto.subtle.importKey(
      'raw', new TextEncoder().encode(keyStr),
      { name:'HMAC', hash:'SHA-256' }, false, ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', km, new TextEncoder().encode(dataStr));
    return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2,'0')).join('');
  } catch (_) { return ''; }
}

async function _cs_generateToken(keyStr, docData, deviceId) {
  const today   = new Date().toISOString().slice(0,10);
  const payload = [
    keyStr,
    (docData && docData.expiry) || 'NONE',
    String(docData && docData.active),
    (docData && docData.owner) || 'ANON',
    deviceId || 'NODEV',
    today,
  ].join('|');
  return _cs_hmacSHA256(_CS_SALT + keyStr, payload);
}

async function _cs_verifyToken(keyStr, docData, storedToken, deviceId) {
  if (!storedToken || typeof storedToken !== 'string') return false;
  if (!keyStr || !docData) return false;
  const expected = await _cs_generateToken(keyStr, docData, deviceId);
  if (!expected || expected.length !== storedToken.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++)
    diff |= expected.charCodeAt(i) ^ storedToken.charCodeAt(i);
  return diff === 0;
}

/* ── FIREBASE INLINE ── */
async function _cs_validateKey(userKey, deviceId) {
  const _FC = [
    'AIzaSyB4IdC3pz4pSGSCH5Ce-u_EYV1CzP9SgtY',
    'inlawry-void-keys','keys','key',
  ];
  const url = 'https://firestore.googleapis.com/v1/projects/' + _FC[1] +
              '/databases/(default)/documents:runQuery?key=' + _FC[0];
  const body = {
    structuredQuery: {
      from: [{ collectionId: _FC[2] }],
      where: { fieldFilter: { field: { fieldPath: _FC[3] }, op:'EQUAL', value:{ stringValue: userKey } } },
      limit: 1,
    },
  };
  let res;
  try {
    res = await fetch(url, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body), cache:'no-store',
    });
  } catch (e) { throw new Error('CONNECTION ERROR'); }
  if (!res.ok) throw new Error('HTTP_' + res.status);
  const json = await res.json();
  if (!Array.isArray(json) || !json[0] || !json[0].document)
    return { valid:false, reason:'INVALID KEY', data:null, token:null, docName:null };

  const rawFields = json[0].document.fields || {};
  const docName   = json[0].document.name;
  const data      = {};
  for (const [k,v] of Object.entries(rawFields)) {
    if      (v.stringValue    !== undefined) data[k] = v.stringValue;
    else if (v.booleanValue   !== undefined) data[k] = v.booleanValue;
    else if (v.integerValue   !== undefined) data[k] = parseInt(v.integerValue,10);
    else if (v.doubleValue    !== undefined) data[k] = parseFloat(v.doubleValue);
    else if (v.timestampValue !== undefined) data[k] = v.timestampValue;
    else if (v.arrayValue     !== undefined)
      data[k] = (v.arrayValue.values||[]).map(i => i.stringValue !== undefined ? i.stringValue : String(i));
    else data[k] = null;
  }

  if (data.active !== true)
    return { valid:false, reason:'KEY REVOKED', data, token:null, docName };
  if (data.expiry) {
    const today  = new Date().toISOString().slice(0,10);
    const expiry = String(data.expiry).slice(0,10);
    if (today > expiry)
      return { valid:false, reason:'KEY EXPIRED (' + expiry + ')', data, token:null, docName };
  }

  const maxDev = (data.max_devices !== undefined && data.max_devices !== null)
    ? parseInt(data.max_devices,10) : null;
  let devices = Array.isArray(data.devices) ? [...data.devices] : [];

  if (!devices.includes(deviceId)) {
    if (maxDev !== null && !isNaN(maxDev) && maxDev > 0 && devices.length >= maxDev)
      return { valid:false, reason:'DEVICE LIMIT REACHED ('+devices.length+'/'+maxDev+')', data, token:null, docName };
    devices.push(deviceId);
    try {
      const pUrl = 'https://firestore.googleapis.com/v1/' + docName +
                   '?key=' + _FC[0] + '&updateMask.fieldPaths=devices';
      await fetch(pUrl, {
        method:'PATCH', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ fields:{ devices:{ arrayValue:{ values: devices.map(d=>({stringValue:d})) } } } }),
        cache:'no-store',
      });
    } catch (_) {}
  }

  const token = await _cs_generateToken(userKey, data, deviceId);
  return { valid:true, reason:'OK', data, token, docName };
}

function _cs_getDeviceId() {
  return new Promise(resolve => {
    chrome.storage.local.get(['_did'], data => {
      if (!chrome.runtime.lastError && data._did && data._did.length >= 16) {
        resolve(data._did); return;
      }
      const arr = new Uint8Array(16);
      crypto.getRandomValues(arr);
      const id = Array.from(arr).map(b => b.toString(16).padStart(2,'0')).join('') +
                 '_' + Date.now().toString(36);
      chrome.storage.local.set({ _did: id }, () => resolve(id));
    });
  });
}

/* ── STATE ── */
const _S = {
  autoScroll:true, engine4K:true, ghostMode:false, autoPromo:true, uiScale:1.0,
  recording:false, mediaRecorder:null, recordedChunks:[], sourceVideo:null,
  overlayActive:false, deviceId:null, licensed:false,
  theme:{ accentR:255, accentG:45, accentB:45, hudR:8, hudG:0, hudB:0, opacity:80 },
};

/* ── STATS ── */
let _statVideos = 0, _statScrolls = 0;

function _initStats() {
  chrome.storage.local.get(['_statVideos','_statScrolls'], data => {
    if (chrome.runtime.lastError) return;
    _statVideos  = data._statVideos  || 0;
    _statScrolls = data._statScrolls || 0;
  });
  chrome.storage.local.set({ _statSessionStart: Date.now() });
}

function _incVideos()  { _statVideos++;  chrome.storage.local.set({ _statVideos }); }
function _incScrolls() { _statScrolls++; chrome.storage.local.set({ _statScrolls }); }

/* ── LICENSE ── */
const REVERIFY_INTERVAL = 60 * 1000;
let _reverifyTimer = null;

async function _verifyLicense() {
  return new Promise(resolve => {
    chrome.storage.local.get(
      ['licenseKey','licenseData','licenseToken','_did'],
      async stored => {
        if (chrome.runtime.lastError) { resolve(false); return; }
        const { licenseKey:key, licenseData:data, licenseToken:token, _did:deviceId } = stored;
        if (!key || !data || !token || !deviceId) { resolve(false); return; }
        try { resolve(await _cs_verifyToken(key, data, token, deviceId)); }
        catch (_) { resolve(false); }
      }
    );
  });
}

async function _startVerification() {
  _S.deviceId = await _cs_getDeviceId();
  let ok = false;
  try { ok = await _verifyLicense(); } catch (_) {}
  _S.licensed = ok;
  if (ok) { _initStats(); _activateEngine(); _scheduleReverify(); }
}

function _scheduleReverify() {
  if (_reverifyTimer) clearInterval(_reverifyTimer);
  _reverifyTimer = setInterval(async () => {
    let ok = false;
    try { ok = await _verifyLicense(); } catch (_) {}
    if (!ok && _S.licensed) {
      _S.licensed = false;
      _deactivateEngine();
      try { chrome.storage.local.remove(['licenseKey','licenseData','licenseToken'], () => {}); } catch (_) {}
      _showExpiredOverlay();
    }
  }, REVERIFY_INTERVAL);
}

/* ── EXPIRED OVERLAY ── */
function _showExpiredOverlay() {
  if (document.getElementById('inlawry-expired-overlay')) return;
  _S.overlayActive = true;
  if (_S.mediaRecorder && _S.mediaRecorder.state !== 'inactive')
    try { _S.mediaRecorder.stop(); } catch (_) {}
  _S.recording = false;

  const ov = document.createElement('div');
  ov.id = 'inlawry-expired-overlay';
  ov.style.cssText = 'position:fixed!important;inset:0!important;z-index:2147483647!important;background:rgba(0,0,0,0.96)!important;display:flex!important;align-items:center!important;justify-content:center!important;backdrop-filter:blur(12px)!important;font-family:-apple-system,BlinkMacSystemFont,sans-serif!important;pointer-events:all!important;';

  ov.innerHTML = `
    <div style="background:#161616;border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:32px 28px;width:310px;max-width:90vw;display:flex;flex-direction:column;align-items:center;gap:14px;box-shadow:0 20px 60px rgba(0,0,0,0.8);">
      <div style="font-size:13px;font-weight:700;color:#fff;letter-spacing:0.3px;">INLAWRY+SERGOYOTA</div>
      <div style="font-size:18px;font-weight:700;color:#fff;text-align:center;">License Expired</div>
      <div style="font-size:12px;color:#555;text-align:center;line-height:1.6;">Your license is no longer valid.<br>Enter a new key to continue.</div>
      <input id="_ov_inp" type="text" placeholder="VOID-XXXX-XXXX-XXXX" maxlength="24" autocomplete="off" spellcheck="false"
        style="width:100%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:13px 16px;font-family:inherit;font-size:14px;color:#fff;letter-spacing:2px;text-align:center;text-transform:uppercase;box-sizing:border-box;outline:none;"/>
      <button id="_ov_btn" style="width:100%;padding:14px;background:#fff;border:none;border-radius:12px;font-family:inherit;font-size:15px;font-weight:600;color:#000;cursor:pointer;">Activate</button>
      <div id="_ov_st" style="font-size:12px;text-align:center;min-height:18px;color:#555;"></div>
    </div>`;

  document.documentElement.appendChild(ov);

  const inp = ov.querySelector('#_ov_inp');
  const btn = ov.querySelector('#_ov_btn');
  const st  = ov.querySelector('#_ov_st');

  inp.addEventListener('input', () => {
    inp.value = inp.value.toUpperCase().replace(/[^A-Z0-9\-]/g,'');
  });

  const _kb = e => { if (e.target !== inp) { e.stopImmediatePropagation(); e.preventDefault(); } };
  const _sb = e => e.stopImmediatePropagation();
  document.addEventListener('keydown',    _kb, true);
  document.addEventListener('keyup',      _kb, true);
  document.addEventListener('scroll',     _sb, true);
  document.addEventListener('touchstart', _sb, { capture:true, passive:false });
  document.addEventListener('touchmove',  _sb, { capture:true, passive:false });

  async function _try() {
    const raw = inp.value.trim().toUpperCase();
    if (!raw || raw.length < 6) { st.textContent = 'Enter a valid key'; st.style.color = '#ff4444'; return; }
    btn.disabled = true; st.textContent = 'Checking…'; st.style.color = '#ffaa22';
    let result;
    try {
      const devId = _S.deviceId || await _cs_getDeviceId();
      result = await _cs_validateKey(raw, devId);
    } catch (e) {
      st.textContent = 'Connection error'; st.style.color = '#ff4444'; btn.disabled = false; return;
    }
    if (result && result.valid) {
      st.textContent = '✓ Activated'; st.style.color = '#34c759';
      chrome.storage.local.set({
        licenseKey    : raw,
        licenseData   : result.data,
        licenseToken  : result.token,
        licenseDocName: result.docName,
      }, () => {
        if (chrome.runtime.lastError) { st.textContent = 'Storage error'; st.style.color = '#ff4444'; btn.disabled = false; return; }
        _S.licensed = true; _S.overlayActive = false;
        document.removeEventListener('keydown',    _kb, true);
        document.removeEventListener('keyup',      _kb, true);
        document.removeEventListener('scroll',     _sb, true);
        document.removeEventListener('touchstart', _sb, true);
        document.removeEventListener('touchmove',  _sb, true);
        setTimeout(() => { try { ov.remove(); } catch (_) {} }, 600);
        _activateEngine(); _scheduleReverify();
      });
    } else {
      st.textContent = (result && result.reason) || 'Invalid key';
      st.style.color = '#ff4444'; btn.disabled = false;
    }
  }

  btn.addEventListener('click', _try);
  inp.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') _try(); });
  setTimeout(() => { try { inp.focus(); } catch (_) {} }, 100);
}

/* ── ENGINE ── */
function _activateEngine() {
  _loadSettings(() => {
    _buildHUD(); _applyTheme(); _applyEngineSettings();
    _applyGhostMode(); _applyUIScale(); _initVideoObserver();
    if (_isUploadPage()) { _buildStallPanel(); _tryAutoPromo(); }
  });
}

function _deactivateEngine() {
  _stopRAF();
  ['inlawry-hud','inlawry-theme-sheet','inlawry-ghost-sheet','inlawry-stall-panel']
    .forEach(id => { try { document.getElementById(id)?.remove(); } catch (_) {} });
  if (_S.mediaRecorder && _S.mediaRecorder.state !== 'inactive')
    try { _S.mediaRecorder.stop(); } catch (_) {}
  _S.recording = false;
  if (_reverifyTimer) { clearInterval(_reverifyTimer); _reverifyTimer = null; }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.licenseToken || changes.licenseKey || changes.licenseData) {
    _startVerification(); return;
  }
  if (!_S.licensed || _S.overlayActive) return;
  for (const [k, { newValue }] of Object.entries(changes)) {
    if (k === 'theme') { _S.theme = { ..._S.theme, ...newValue }; _applyTheme(); }
    else if (k in _S)  _S[k] = newValue;
  }
  _applyEngineSettings(); _applyGhostMode(); _applyUIScale(); _updateHUD();
});

/* ── THEME ── */
function _applyTheme() {
  if (_S.overlayActive) return;
  const t = _S.theme;
  const accent  = `${t.accentR},${t.accentG},${t.accentB}`;
  const hud     = `${t.hudR},${t.hudG},${t.hudB}`;
  const opacity = ((t.opacity !== undefined ? t.opacity : 80) / 100).toFixed(2);

  let sheet = document.getElementById('inlawry-theme-sheet');
  if (!sheet) {
    sheet = document.createElement('style');
    sheet.id = 'inlawry-theme-sheet';
    document.documentElement.appendChild(sheet);
  }
  sheet.textContent = `
    #inlawry-hud{
      background:rgba(${hud},${opacity})!important;
      border-color:rgba(${accent},0.2)!important;
    }
    .hud-val.on { color:rgb(${accent})!important; }
    .hud-brand  { color:rgba(${accent},0.6)!important; }
    .inlawry-watermark { border-left-color:rgba(${accent},0.7)!important; }
    .inlawry-toast-ok  { color:rgb(${accent})!important; border-color:rgba(${accent},0.3)!important; }
  `;
}

/* ── SETTINGS ── */
function _loadSettings(cb) {
  try {
    chrome.storage.local.get(
      ['autoScroll','engine4K','ghostMode','autoPromo','uiScale','theme'],
      data => {
        if (chrome.runtime.lastError) { cb(); return; }
        if (data.autoScroll !== undefined) _S.autoScroll = data.autoScroll;
        if (data.engine4K   !== undefined) _S.engine4K   = data.engine4K;
        if (data.ghostMode  !== undefined) _S.ghostMode  = data.ghostMode;
        if (data.autoPromo  !== undefined) _S.autoPromo  = data.autoPromo;
        if (data.uiScale    !== undefined) _S.uiScale    = data.uiScale;
        if (data.theme) _S.theme = { ..._S.theme, ...data.theme };
        cb();
      }
    );
  } catch (_) { cb(); }
}

/* ── QUALITY ENGINE ── */
function _spoofConnection() {
  try {
    if (!('connection' in navigator)) return;
    const fake = { downlink:100, rtt:5, effectiveType:'4g', saveData:false,
      addEventListener:()=>{}, removeEventListener:()=>{}, dispatchEvent:()=>true };
    Object.defineProperty(navigator, 'connection', { get:()=>fake, configurable:true });
  } catch (_) {}
}

function _accelerateVideo(v) {
  if (!v || v.dataset.inlawryAccel) return;
  v.dataset.inlawryAccel     = '1';
  v.style.transform          = 'translateZ(0)';
  v.style.webkitTransform    = 'translateZ(0)';
  v.style.willChange         = 'transform';
  v.style.imageRendering     = 'crisp-edges';
  v.style.backfaceVisibility = 'hidden';
}

let _rafHandle = null;
function _startRAF() {
  if (_rafHandle) return;
  let last = 0;
  function tick(ts) { if (ts - last >= 1000/120) last = ts; _rafHandle = requestAnimationFrame(tick); }
  _rafHandle = requestAnimationFrame(tick);
}
function _stopRAF() { if (_rafHandle) { cancelAnimationFrame(_rafHandle); _rafHandle = null; } }

function _applyEngineSettings() {
  if (_S.overlayActive) return;
  if (_S.engine4K) { _startRAF(); document.querySelectorAll('video').forEach(_accelerateVideo); }
  else _stopRAF();
}

/* ── HUD ── */
function _buildHUD() {
  if (_S.overlayActive || document.getElementById('inlawry-hud')) return;
  const hud = document.createElement('div');
  hud.id = 'inlawry-hud';
  hud.innerHTML = `
    <div class="hud-row" id="hud-engine">ENGINE <span class="hud-val on">4K</span></div>
    <div class="hud-row" id="hud-scroll">SCROLL <span class="hud-val on">ON</span></div>
    <div class="hud-row" id="hud-ghost">GHOST  <span class="hud-val off">OFF</span></div>
    <div class="hud-row hud-brand">@INLAWRY+SERGOYOTA</div>`;
  document.documentElement.appendChild(hud);
  _updateHUD();
}

function _updateHUD() {
  if (_S.overlayActive) return;
  const rows = {
    'hud-engine': [_S.engine4K   ? '4K' : 'OFF', _S.engine4K],
    'hud-scroll': [_S.autoScroll ? 'ON' : 'OFF', _S.autoScroll],
    'hud-ghost' : [_S.ghostMode  ? 'ON' : 'OFF', _S.ghostMode],
  };
  for (const [id, [txt, on]] of Object.entries(rows)) {
    const el = document.getElementById(id); if (!el) continue;
    const sp = el.querySelector('.hud-val');
    if (sp) { sp.textContent = txt; sp.className = 'hud-val ' + (on ? 'on' : 'off'); }
  }
}

/* ── GHOST ── */
const _GHOST_SEL = [
  '[data-e2e="browse-username"]','[data-e2e="video-desc"]',
  '[data-e2e="like-container"]', '[data-e2e="comment-icon"]',
  '[data-e2e="share-icon"]',     'header',
  '[class*="DivHeader"]',        '[class*="SpanUniqueId"]',
  '[class*="action-bar"]',       '[class*="ActionBar"]',
  '[class*="SideBar"]',
].join(',');

function _applyGhostMode() {
  if (_S.overlayActive) return;
  let s = document.getElementById('inlawry-ghost-sheet');
  if (_S.ghostMode) {
    if (!s) {
      s = document.createElement('style');
      s.id = 'inlawry-ghost-sheet';
      s.textContent = `${_GHOST_SEL}{opacity:0!important;pointer-events:none!important;transition:opacity 0.35s ease!important}`;
      document.documentElement.appendChild(s);
    }
  } else { if (s) s.remove(); }
}

function _applyUIScale() {
  if (_S.overlayActive) return;
  try { document.body.style.zoom = String(_S.uiScale); } catch (_) {}
}

/* ── WATERMARK ── */
const _WM_TEXT  = 'HQ_VERIFIED // @INLAWRY+SERGOYOTA';
const _wmVideos = new WeakSet();

function _addWatermark(v) {
  if (_S.overlayActive || !v || _wmVideos.has(v)) return;
  _wmVideos.add(v);
  const c = v.closest('[class*="DivContainer"]') || v.closest('[class*="video-feed"]') || v.parentElement;
  if (!c || c.querySelector('.inlawry-watermark')) return;
  try {
    if (getComputedStyle(c).position === 'static') c.style.position = 'relative';
    const wm = document.createElement('div');
    wm.className = 'inlawry-watermark'; wm.textContent = _WM_TEXT;
    c.appendChild(wm);
  } catch (_) {}
}

/* ── AUTO-SCROLL ── */
function _attachAutoScroll(v) {
  if (!v || v.dataset.inlawryScroll) return;
  v.dataset.inlawryScroll = '1';
  v.addEventListener('ended', () => {
    if (!_S.autoScroll || !_S.licensed || _S.overlayActive) return;
    _incScrolls();
    try {
      const btn = document.querySelector('[data-e2e="arrow-right"]');
      if (btn) setTimeout(() => btn.click(), 300);
    } catch (_) {}
  });
}

/* ── VIDEO OBSERVER ── */
function _processVideo(v) {
  if (_S.overlayActive || !v) return;
  if (_S.engine4K) _accelerateVideo(v);
  _addWatermark(v); _attachAutoScroll(v);
  _incVideos();
}

function _initVideoObserver() {
  document.querySelectorAll('video').forEach(_processVideo);
  new MutationObserver(muts => {
    if (_S.overlayActive) return;
    for (const m of muts) for (const n of m.addedNodes) {
      if (n.nodeType !== 1) continue;
      if (n.tagName === 'VIDEO') _processVideo(n);
      else if (n.querySelectorAll) n.querySelectorAll('video').forEach(_processVideo);
    }
  }).observe(document.documentElement, { childList:true, subtree:true });
}

/* ── HOTKEY ── */
document.addEventListener('keydown', e => {
  if (!_S.licensed || _S.overlayActive) return;
  const tag = e.target && e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA') return;
  if (e.key === 'c' || e.key === 'C') {
    _S.ghostMode = !_S.ghostMode;
    chrome.storage.local.set({ ghostMode: _S.ghostMode });
    _applyGhostMode(); _updateHUD();
  }
});

/* ── UPLOAD ── */
const _CAPTION_TEXT =
  '\uD83D\uDD34 HQ_VERIFIED // @INLAWRY+SERGOYOTA\n' +
  '#INLAWRY #SERGOYOTA #4K #VOID_QUALITY #HQ_VERIFIED\n' +
  '\u2726 Infected by @inlawry x @sergoyota \u2726';

const _CAPTION_SELS = [
  '[data-e2e="upload-caption"]','.public-DraftEditor-content',
  '[contenteditable="true"].notranslate','[class*="DraftEditor-content"]',
  '[class*="caption-input"]','[contenteditable="true"][class*="caption"]',
  'div[contenteditable="true"]',
];

function _isUploadPage() { return location.pathname.startsWith('/upload'); }

function _tryAutoPromo() {
  if (!_S.autoPromo || _S.overlayActive) return;
  let retries = 0;
  const MAX = 40, DELAY = 500;

  function findEl() {
    for (const sel of _CAPTION_SELS) {
      try { const el = document.querySelector(sel); if (el && !el.dataset.inlawryPromo) return el; }
      catch (_) {}
    }
    return null;
  }

  function fill(el) {
    try {
      el.dataset.inlawryPromo = '1'; el.focus();
      if (el.tagName === 'TEXTAREA') {
        el.value = _CAPTION_TEXT;
        el.dispatchEvent(new Event('input',  { bubbles:true }));
        el.dispatchEvent(new Event('change', { bubbles:true }));
        return;
      }
      try { document.execCommand('selectAll',false,null); document.execCommand('delete',false,null); }
      catch (_) { el.textContent = ''; }
      const lines = _CAPTION_TEXT.split('\n');
      try {
        for (let i = 0; i < lines.length; i++) {
          document.execCommand('insertText', false, lines[i]);
          if (i < lines.length-1) {
            el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,bubbles:true,cancelable:true}));
            document.execCommand('insertParagraph',false,null);
          }
        }
      } catch (_) { el.textContent = _CAPTION_TEXT; el.dispatchEvent(new Event('input',{bubbles:true})); }
    } catch (_) {}
  }

  function attempt() {
    if (_S.overlayActive) return;
    const el = findEl();
    if (el) {
      fill(el);
      setTimeout(() => {
        const content = el.textContent || el.value || '';
        if (!content.includes('INLAWRY') && retries < MAX) {
          delete el.dataset.inlawryPromo; retries++;
          setTimeout(attempt, DELAY);
        } else { _showToast('\u2714 Caption injected', 'ok'); }
      }, 300);
    } else if (retries < MAX) { retries++; setTimeout(attempt, DELAY); }
  }
  setTimeout(attempt, 800);
}

function _showToast(msg, type) {
  if (_S.overlayActive) return;
  try {
    const t = document.createElement('div');
    t.className   = 'inlawry-toast inlawry-toast-' + (type||'ok');
    t.textContent = msg;
    document.documentElement.appendChild(t);
    setTimeout(() => { try { t.remove(); } catch (_) {} }, 3000);
  } catch (_) {}
}

/* ── STALL PANEL (upload page) ── */
function _buildStallPanel() {
  if (_S.overlayActive || document.getElementById('inlawry-stall-panel')) return;
  const p = document.createElement('div');
  p.id = 'inlawry-stall-panel';
  p.innerHTML = `
    <div class="stall-header">
      <span class="stall-logo">INLAWRY+SERGOYOTA</span>
      <span class="stall-sub">UPLOAD HELPER</span>
    </div>
    <div class="stall-body">
      <div class="stall-row">
        <label>Auto-Promo</label>
        <span id="stall-status" class="stall-status ok">ACTIVE</span>
      </div>
    </div>`;
  document.documentElement.appendChild(p);
}

/* ── SPA WATCHER ── */
let _lastPath = location.pathname;
new MutationObserver(() => {
  if (location.pathname !== _lastPath) {
    _lastPath = location.pathname;
    if (_S.licensed && !_S.overlayActive && _isUploadPage()) {
      _buildStallPanel(); _tryAutoPromo();
    }
  }
}).observe(document.body || document.documentElement, { childList:true, subtree:true });

/* ── BOOT ── */
function _boot() { _spoofConnection(); _startVerification(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _boot);
else _boot();
